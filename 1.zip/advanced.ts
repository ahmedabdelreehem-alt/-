import { router, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import { generateAvatarResponse, processCommand } from '../services/aiResponses';

import { memorySystem, initializeDummyMemories } from '../services/memorySystem';
import { financialSystem, initializeDummyFinancialData } from '../services/financialSystem';
import { medicalCentersSystem, initializeDummyMedicalData } from '../services/medicalCentersSystem';
import { multiAgentSystem } from '../services/multiAgentSystem';

export const advancedRouter = router({
  // AI Responses
  getAvatarResponse: protectedProcedure
    .input(
      z.object({
        message: z.string(),
        conversationHistory: z
          .array(
            z.object({
              role: z.enum(['user', 'assistant']),
              content: z.string(),
            })
          )
          .optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const response = await generateAvatarResponse(input.message, input.conversationHistory);

      // حفظ في الذاكرة
      memorySystem.addMemory({
        userId: ctx.user!.id,
        content: `User: ${input.message}`,
        importance: 0.5,
        category: 'interaction',
        tags: ['chat', 'user_message'],
      });

      memorySystem.addMemory({
        userId: ctx.user!.id,
        content: `Assistant: ${response.text}`,
        importance: 0.5,
        category: 'interaction',
        tags: ['chat', 'assistant_response'],
      });

      return response;
    }),

  processCommand: protectedProcedure
    .input(z.object({ command: z.string() }))
    .mutation(async ({ input, ctx }) => {
      const result = await processCommand(input.command);

      // معالجة الأمر من خلال Multi-Agent System
      const agentResponse = await multiAgentSystem.processCommand(input.command);

      return {
        ...result,
        agentResponse,
      };
    }),

  // Memory System
  getUserMemories: protectedProcedure
    .input(
      z.object({
        query: z.string().optional(),
        limit: z.number().optional().default(10),
      })
    )
    .query(({ input, ctx }) => {
      if (input.query) {
        return memorySystem.searchMemories(ctx.user!.id, input.query, input.limit);
      }
      return memorySystem.exportMemories(ctx.user!.id).slice(-input.limit);
    }),

  getConversationContext: protectedProcedure.query(({ ctx }) => {
    return memorySystem.getConversationContext(ctx.user!.id);
  }),

  updateUserPreferences: protectedProcedure
    .input(z.object({ preferences: z.record(z.string(), z.any()) }))
    .mutation(({ input, ctx }) => {
      memorySystem.updatePreferences(ctx.user!.id, input.preferences);
      return { success: true };
    }),

  // Financial System
  getFinancialAccounts: protectedProcedure.query(({ ctx }) => {
    return financialSystem.getAccounts(ctx.user!.id);
  }),

  getFinancialTransactions: protectedProcedure
    .input(z.object({ limit: z.number().optional().default(50) }))
    .query(({ input, ctx }) => {
      return financialSystem.getTransactions(ctx.user!.id, input.limit);
    }),

  generateFinancialReport: protectedProcedure
    .input(z.object({ period: z.enum(['daily', 'weekly', 'monthly', 'yearly']).optional() }))
    .query(({ input, ctx }) => {
      const period = (input?.period || 'monthly') as 'daily' | 'weekly' | 'monthly' | 'yearly';
      return financialSystem.generateReport(ctx.user!.id, period);
    }),

  getFinancialStatistics: protectedProcedure.query(({ ctx }) => {
    return financialSystem.getStatistics(ctx.user!.id);
  }),

  // Medical Centers System
  getMedicalCenters: protectedProcedure.query(({ ctx }) => {
    return medicalCentersSystem.getCenters(ctx.user!.id);
  }),

  getMedicalCenterStatistics: protectedProcedure
    .input(z.object({ centerId: z.string() }))
    .query(({ input }) => {
      return medicalCentersSystem.getCenterStatistics(input.centerId);
    }),

  getAllMedicalCentersReport: protectedProcedure.query(({ ctx }) => {
    return medicalCentersSystem.getAllCentersReport(ctx.user!.id);
  }),

  getMedicalCenterPatients: protectedProcedure
    .input(z.object({ centerId: z.string() }))
    .query(({ input }) => {
      return medicalCentersSystem.getPatients(input.centerId);
    }),

  getMedicalCenterStaff: protectedProcedure
    .input(z.object({ centerId: z.string() }))
    .query(({ input }) => {
      return medicalCentersSystem.getStaff(input.centerId);
    }),

  // Multi-Agent System
  getAgents: protectedProcedure.query(() => {
    return multiAgentSystem.getAgents();
  }),

  getAgentTasks: protectedProcedure
    .input(z.object({ agentId: z.string(), status: z.string().optional() }))
    .query(({ input }) => {
      return multiAgentSystem.getAgentTasks(input.agentId, input.status);
    }),

  getSystemStatistics: protectedProcedure.query(() => {
    return multiAgentSystem.getSystemStatistics();
  }),

  // Initialize Dummy Data
  initializeDummyData: protectedProcedure.mutation(({ ctx }) => {
    const userId = ctx.user!.id;

    initializeDummyMemories(userId);
    initializeDummyFinancialData(userId);
    initializeDummyMedicalData(userId);

    return {
      success: true,
      message: 'تم تهيئة البيانات التجريبية بنجاح',
    };
  }),
});
