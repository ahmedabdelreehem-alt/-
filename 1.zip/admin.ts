import { protectedProcedure, router } from '../_core/trpc';
import { z } from 'zod';
import { TRPCError } from '@trpc/server';

export const adminRouter = router({
  getUsers: protectedProcedure
    .query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
      }

      return {
        users: [
          {
            id: ctx.user.id,
            name: ctx.user.name,
            email: ctx.user.email,
            role: ctx.user.role,
            createdAt: ctx.user.createdAt,
            lastSignedIn: ctx.user.lastSignedIn,
          },
        ],
      };
    }),

  updateUserRole: protectedProcedure
    .input(z.object({
      userId: z.number(),
      role: z.enum(['user', 'admin']),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
      }

      return {
        success: true,
        userId: input.userId,
        newRole: input.role,
        updatedAt: new Date(),
      };
    }),

  getSystemStatus: protectedProcedure
    .query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
      }

      return {
        status: 'operational',
        services: {
          chat: { status: 'online', uptime: '99.9%' },
          avatar: { status: 'online', uptime: '99.8%' },
          database: { status: 'online', uptime: '99.95%' },
        },
        metrics: {
          activeUsers: 1,
          totalMessages: 42,
          apiLatency: 45,
        },
      };
    }),

  controlService: protectedProcedure
    .input(z.object({
      service: z.string(),
      action: z.enum(['start', 'stop', 'restart']),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
      }

      return {
        success: true,
        service: input.service,
        action: input.action,
        result: `Service "${input.service}" ${input.action} command sent`,
        timestamp: new Date(),
      };
    }),

  updateSettings: protectedProcedure
    .input(z.object({
      key: z.string(),
      value: z.any(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
      }

      return {
        success: true,
        setting: input.key,
        newValue: input.value,
        updatedAt: new Date(),
      };
    }),

  getAuditLog: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
    }))
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
      }

      return {
        logs: [
          {
            id: 'log_1',
            action: 'USER_LOGIN',
            userId: ctx.user.id,
            timestamp: new Date(),
            details: 'User logged in successfully',
          },
        ],
      };
    }),
});

export type AdminRouter = typeof adminRouter;
