import React, { useState } from 'react';
import { Settings, Users, Activity, AlertCircle, Power } from 'lucide-react';

interface Service {
  name: string;
  status: 'online' | 'offline' | 'warning';
  uptime: string;
}

export const AdminDashboard: React.FC = () => {
  const [services, setServices] = useState<Service[]>([
    { name: 'Chat Service', status: 'online', uptime: '99.9%' },
    { name: 'Avatar Engine', status: 'online', uptime: '99.8%' },
    { name: 'Database', status: 'online', uptime: '99.95%' },
    { name: 'API Gateway', status: 'online', uptime: '99.7%' },
  ]);

  const [metrics] = useState({
    activeUsers: 1,
    totalMessages: 42,
    apiLatency: 45,
    errorRate: 0.01,
  });

  const handleServiceControl = (serviceName: string, action: 'start' | 'stop' | 'restart') => {
    console.log(`${action} ${serviceName}`);
  };

  return (
    <div className="w-full space-y-6">
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl border border-purple-500/30 p-6">
        <h2 className="text-2xl font-bold text-purple-400 mb-6 flex items-center gap-2">
          <Settings className="w-6 h-6" />
          Admin Control Panel
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-700/50 rounded-lg p-4 border border-purple-500/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Active Users</p>
                <p className="text-2xl font-bold text-purple-400">{metrics.activeUsers}</p>
              </div>
              <Users className="w-8 h-8 text-purple-400 opacity-50" />
            </div>
          </div>

          <div className="bg-slate-700/50 rounded-lg p-4 border border-purple-500/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total Messages</p>
                <p className="text-2xl font-bold text-purple-400">{metrics.totalMessages}</p>
              </div>
              <Activity className="w-8 h-8 text-purple-400 opacity-50" />
            </div>
          </div>

          <div className="bg-slate-700/50 rounded-lg p-4 border border-purple-500/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">API Latency</p>
                <p className="text-2xl font-bold text-purple-400">{metrics.apiLatency}ms</p>
              </div>
              <Activity className="w-8 h-8 text-green-400 opacity-50" />
            </div>
          </div>

          <div className="bg-slate-700/50 rounded-lg p-4 border border-purple-500/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Error Rate</p>
                <p className="text-2xl font-bold text-purple-400">{(metrics.errorRate * 100).toFixed(2)}%</p>
              </div>
              <AlertCircle className="w-8 h-8 text-green-400 opacity-50" />
            </div>
          </div>
        </div>

        <div className="bg-slate-700/30 rounded-lg p-6 border border-purple-500/20">
          <h3 className="text-lg font-semibold text-purple-400 mb-4 flex items-center gap-2">
            <Power className="w-5 h-5" />
            Service Management
          </h3>

          <div className="space-y-3">
            {services.map((service) => (
              <div
                key={service.name}
                className="flex items-center justify-between bg-slate-800/50 p-4 rounded-lg border border-slate-600/50"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        service.status === 'online'
                          ? 'bg-green-500'
                          : service.status === 'warning'
                            ? 'bg-yellow-500'
                            : 'bg-red-500'
                      }`}
                    />
                    <span className="font-medium text-slate-100">{service.name}</span>
                  </div>
                  <p className="text-sm text-slate-400 mt-1">Uptime: {service.uptime}</p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleServiceControl(service.name, 'restart')}
                    className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded transition-colors"
                  >
                    Restart
                  </button>
                  <button
                    onClick={() => handleServiceControl(service.name, 'stop')}
                    className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-sm rounded transition-colors"
                  >
                    Stop
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 bg-slate-700/30 rounded-lg p-6 border border-purple-500/20">
          <h3 className="text-lg font-semibold text-purple-400 mb-4">System Settings</h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-slate-300">Enable Maintenance Mode</label>
              <input type="checkbox" className="w-5 h-5 cursor-pointer" />
            </div>

            <div className="flex items-center justify-between">
              <label className="text-slate-300">Enable Debug Logging</label>
              <input type="checkbox" className="w-5 h-5 cursor-pointer" />
            </div>

            <div className="flex items-center justify-between">
              <label className="text-slate-300">Enable Rate Limiting</label>
              <input type="checkbox" defaultChecked className="w-5 h-5 cursor-pointer" />
            </div>

            <div className="flex items-center justify-between">
              <label className="text-slate-300">Enable Encryption</label>
              <input type="checkbox" defaultChecked className="w-5 h-5 cursor-pointer" />
            </div>
          </div>

          <button className="w-full mt-6 px-4 py-2 bg-gradient-to-r from-purple-600 to-violet-600 hover:shadow-lg hover:shadow-purple-500/50 text-white rounded-lg font-semibold transition-all">
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
