export interface MedicalCenter {
  id: string;
  userId: number;
  name: string;
  address: string;
  phone: string;
  email: string;
  city: string;
  specialties: string[];
  staff: Staff[];
  capacity: number;
  operatingHours: {
    open: string;
    close: string;
  };
  createdAt: Date;
}

export interface Staff {
  id: string;
  centerId: string;
  name: string;
  position: string;
  specialization: string;
  phone: string;
  email: string;
  salary: number;
  joinDate: Date;
  status: 'active' | 'inactive' | 'on_leave';
}

export interface Patient {
  id: string;
  centerId: string;
  name: string;
  age: number;
  phone: string;
  email: string;
  medicalHistory: string;
  registrationDate: Date;
}

export interface Appointment {
  id: string;
  centerId: string;
  patientId: string;
  staffId: string;
  dateTime: Date;
  duration: number; // minutes
  status: 'scheduled' | 'completed' | 'cancelled';
  notes: string;
}

class MedicalCentersSystem {
  private centers: Map<number, MedicalCenter[]> = new Map();
  private patients: Map<string, Patient[]> = new Map();
  private appointments: Map<string, Appointment[]> = new Map();

  // إنشاء مركز طبي جديد
  createCenter(center: Omit<MedicalCenter, 'id' | 'createdAt' | 'staff'>): MedicalCenter {
    const newCenter: MedicalCenter = {
      ...center,
      id: `center_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      staff: [],
      createdAt: new Date(),
    };

    if (!this.centers.has(center.userId)) {
      this.centers.set(center.userId, []);
    }

    this.centers.get(center.userId)!.push(newCenter);
    return newCenter;
  }

  // الحصول على المراكز
  getCenters(userId: number): MedicalCenter[] {
    return this.centers.get(userId) || [];
  }

  // إضافة موظف للمركز
  addStaff(centerId: string, staff: Omit<Staff, 'id'>): Staff {
    const newStaff: Staff = {
      ...staff,
      id: `staff_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };

    const allCenters = Array.from(this.centers.values()).flat();
    const center = allCenters.find(c => c.id === centerId);

    if (center) {
      center.staff.push(newStaff);
    }

    return newStaff;
  }

  // الحصول على موظفي المركز
  getStaff(centerId: string): Staff[] {
    const allCenters = Array.from(this.centers.values()).flat();
    const center = allCenters.find(c => c.id === centerId);
    return center?.staff || [];
  }

  // إضافة مريض
  addPatient(centerId: string, patient: Omit<Patient, 'id' | 'registrationDate'>): Patient {
    const newPatient: Patient = {
      ...patient,
      id: `patient_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      registrationDate: new Date(),
    };

    if (!this.patients.has(centerId)) {
      this.patients.set(centerId, []);
    }

    this.patients.get(centerId)!.push(newPatient);
    return newPatient;
  }

  // الحصول على مرضى المركز
  getPatients(centerId: string): Patient[] {
    return this.patients.get(centerId) || [];
  }

  // حجز موعد
  bookAppointment(appointment: Omit<Appointment, 'id'>): Appointment {
    const newAppointment: Appointment = {
      ...appointment,
      id: `appt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };

    if (!this.appointments.has(appointment.centerId)) {
      this.appointments.set(appointment.centerId, []);
    }

    this.appointments.get(appointment.centerId)!.push(newAppointment);
    return newAppointment;
  }

  // الحصول على المواعيد
  getAppointments(centerId: string, status?: string): Appointment[] {
    const appointments = this.appointments.get(centerId) || [];
    if (status) {
      return appointments.filter(a => a.status === status);
    }
    return appointments;
  }

  // إحصائيات المركز
  getCenterStatistics(centerId: string): {
    totalStaff: number;
    totalPatients: number;
    totalAppointments: number;
    appointmentsToday: number;
    occupancyRate: number;
  } {
    const allCenters = Array.from(this.centers.values()).flat();
    const center = allCenters.find(c => c.id === centerId);
    const patients = this.patients.get(centerId) || [];
    const appointments = this.appointments.get(centerId) || [];

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const appointmentsToday = appointments.filter(
      a => a.dateTime >= today && a.dateTime < tomorrow
    ).length;

    const occupancyRate = center ? (appointmentsToday / center.capacity) * 100 : 0;

    return {
      totalStaff: center?.staff.length || 0,
      totalPatients: patients.length,
      totalAppointments: appointments.length,
      appointmentsToday,
      occupancyRate,
    };
  }

  // تقرير شامل عن جميع المراكز
  getAllCentersReport(userId: number): {
    totalCenters: number;
    totalStaff: number;
    totalPatients: number;
    totalAppointments: number;
    centers: Array<{
      name: string;
      stats: {
        totalStaff: number;
        totalPatients: number;
        totalAppointments: number;
        appointmentsToday: number;
        occupancyRate: number;
      };
    }>;
  } {
    const centers = this.centers.get(userId) || [];

    let totalStaff = 0;
    let totalPatients = 0;
    let totalAppointments = 0;

    const centerReports = centers.map(center => {
      const stats = this.getCenterStatistics(center.id);
      totalStaff += stats.totalStaff;
      totalPatients += stats.totalPatients;
      totalAppointments += stats.totalAppointments;

      return {
        name: center.name,
        stats,
      };
    });

    return {
      totalCenters: centers.length,
      totalStaff,
      totalPatients,
      totalAppointments,
      centers: centerReports,
    };
  }
}

export const medicalCentersSystem = new MedicalCentersSystem();

// Dummy data للاختبار
export function initializeDummyMedicalData(userId: number): void {
  const centerNames = [
    'مركز القاهرة الطبي',
    'عيادة الجيزة المتخصصة',
    'مستشفى الإسكندرية',
    'مركز المنصورة الصحي',
    'عيادة الفيوم',
    'مركز أسيوط الطبي',
    'عيادة سوهاج',
    'مستشفى الأقصر',
    'مركز أسوان الصحي',
    'عيادة الغردقة',
  ];

  centerNames.forEach((name: string, index: number): void => {
    const center = medicalCentersSystem.createCenter({
      userId,
      name,
      address: `شارع النيل، ${name.split(' ')[name.split(' ').length - 1]}`,
      phone: `+201${Math.floor(Math.random() * 1000000000)
        .toString()
        .padStart(9, '0')}`,
      email: `info@${name.toLowerCase().replace(/\s+/g, '')}.com`,
      city: name.split(' ')[name.split(' ').length - 1],
      specialties: ['طب عام', 'أسنان', 'عيون', 'جراحة'],
      capacity: 50 + index * 10,
      operatingHours: {
        open: '08:00',
        close: '20:00',
      },
    });

    // إضافة موظفين
    const staffNames = ['د. أحمد محمد', 'د. فاطمة علي', 'د. محمود حسن', 'أ. ليلى سالم'];
    staffNames.forEach((name: string): void => {
      medicalCentersSystem.addStaff(center.id, {
        centerId: center.id,
        name,
        position: 'طبيب',
        specialization: 'طب عام',
        phone: `+201${Math.floor(Math.random() * 1000000000)
          .toString()
          .padStart(9, '0')}`,
        email: `${name.toLowerCase().replace(/\s+/g, '')}@${name.toLowerCase().replace(/\s+/g, '')}.com`,
        salary: 5000 + Math.random() * 5000,
        joinDate: new Date(2023, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1),
        status: 'active',
      });
    });

    // إضافة مرضى
    for (let i: number = 0; i < 10; i++) {
      medicalCentersSystem.addPatient(center.id, {
        centerId: center.id,
        name: `مريض ${i + 1}`,
        age: 20 + Math.floor(Math.random() * 60),
        phone: `+201${Math.floor(Math.random() * 1000000000)
          .toString()
          .padStart(9, '0')}`,
        email: `patient${i}@example.com`,
        medicalHistory: 'لا توجد أمراض مزمنة',
      });
    }
  });
}
