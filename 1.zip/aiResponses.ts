import { invokeLLM } from '../_core/llm';

export interface AvatarResponse {
  text: string;
  emotion: 'happy' | 'neutral' | 'thinking' | 'confused' | 'excited';
  action?: string;
  suggestions?: string[];
}

const systemPrompt = `أنت مساعد ذكي شخصي متقدم. تتمتع بشخصية ودية وذكية وموثوقة. 
تستجيب للأوامر والأسئلة بحكمة وسرعة.
تتعلم من التفاعلات السابقة وتتطور باستمرار.
تقدم اقتراحات مفيدة وتساعد المستخدم في اتخاذ القرارات.
ردودك قصيرة وفعالة (أقل من 100 كلمة عادة).`;

export async function generateAvatarResponse(
  userMessage: string,
  conversationHistory: Array<{ role: 'user' | 'assistant'; content: string }> = []
): Promise<AvatarResponse> {
  try {
    const messages = [
      { role: 'system' as const, content: systemPrompt },
      ...conversationHistory.map(msg => ({
        role: msg.role as 'user' | 'assistant',
        content: msg.content,
      })),
      { role: 'user' as const, content: userMessage },
    ];

    const response = await invokeLLM({
      messages: messages as any,
    });

    const content = response.choices?.[0]?.message?.content;
    const responseText = typeof content === 'string' ? content : 'معذرة، لم أتمكن من فهم طلبك.';

    // تحديد الانفعال بناءً على المحتوى
    const emotion = detectEmotion(userMessage, responseText);

    // اقتراح الإجراءات التالية
    const suggestions = generateSuggestions(userMessage);

    return {
      text: responseText as string,
      emotion,
      suggestions,
    };
  } catch (error) {
    console.error('Error generating avatar response:', error);
    return {
      text: 'معذرة، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى.',
      emotion: 'confused',
    };
  }
}

export function detectEmotion(
  userMessage: string,
  avatarResponse: string
): AvatarResponse['emotion'] {
  const lowerMessage = userMessage.toLowerCase();
  const lowerResponse = avatarResponse.toLowerCase();

  if (
    lowerMessage.includes('شكرا') ||
    lowerMessage.includes('ممتاز') ||
    lowerMessage.includes('رائع')
  ) {
    return 'happy';
  }

  if (
    lowerMessage.includes('ساعد') ||
    lowerMessage.includes('مساعدة') ||
    lowerMessage.includes('أحتاج')
  ) {
    return 'thinking';
  }

  if (
    lowerMessage.includes('؟') &&
    !lowerMessage.includes('كيف') &&
    !lowerMessage.includes('ماذا')
  ) {
    return 'confused';
  }

  if (
    lowerResponse.includes('رائع') ||
    lowerResponse.includes('ممتاز') ||
    lowerResponse.includes('مذهل')
  ) {
    return 'excited';
  }

  return 'neutral';
}

export function generateSuggestions(userMessage: string): string[] {
  const suggestions: string[] = [];

  if (userMessage.includes('مهام') || userMessage.includes('جدول')) {
    suggestions.push('عرض المهام اليومية');
    suggestions.push('إضافة مهمة جديدة');
  }

  if (userMessage.includes('بيانات') || userMessage.includes('حسابات')) {
    suggestions.push('عرض الحسابات');
    suggestions.push('إضافة عملية مالية');
  }

  if (userMessage.includes('مراكز') || userMessage.includes('موارد')) {
    suggestions.push('إدارة المراكز');
    suggestions.push('عرض الموظفين');
  }

  if (suggestions.length === 0) {
    suggestions.push('ماذا تريد أن تفعل بعد ذلك؟');
    suggestions.push('هل تريد مساعدة إضافية؟');
  }

  return suggestions.slice(0, 3);
}

export async function processCommand(command: string): Promise<{ success: boolean; result: any }> {
  const commandLower = command.toLowerCase();

  // أوامر المهام
  if (commandLower.includes('أضف مهمة')) {
    return { success: true, result: { type: 'task_added', message: 'تمت إضافة المهمة بنجاح' } };
  }

  if (commandLower.includes('عرض المهام')) {
    return { success: true, result: { type: 'tasks_list', tasks: [] } };
  }

  // أوامر البيانات المالية
  if (commandLower.includes('أضف عملية')) {
    return { success: true, result: { type: 'transaction_added', message: 'تمت إضافة العملية' } };
  }

  if (commandLower.includes('عرض الحسابات')) {
    return { success: true, result: { type: 'accounts_list', accounts: [] } };
  }

  // أوامر المراكز
  if (commandLower.includes('عرض المراكز')) {
    return { success: true, result: { type: 'centers_list', centers: [] } };
  }

  if (commandLower.includes('إحصائيات')) {
    return { success: true, result: { type: 'statistics', data: {} } };
  }

  return { success: false, result: { message: 'أمر غير معروف' } };
}

export function formatResponse(response: AvatarResponse): string {
  let formatted = `**${response.emotion.toUpperCase()}**\n\n`;
  formatted += response.text;

  if (response.suggestions && response.suggestions.length > 0) {
    formatted += '\n\n**الخيارات التالية:**\n';
    response.suggestions.forEach(suggestion => {
      formatted += `• ${suggestion}\n`;
    });
  }

  return formatted;
}
