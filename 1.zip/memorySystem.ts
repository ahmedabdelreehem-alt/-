export interface Memory {
  id: string;
  userId: number;
  content: string;
  timestamp: Date;
  importance: number; // 0-1
  category: 'task' | 'preference' | 'fact' | 'interaction' | 'financial' | 'medical';
  tags: string[];
  embedding?: number[]; // سيتم استخدامه مع Vector DB الحقيقي
}

export interface ConversationContext {
  userId: number;
  recentMessages: Array<{ role: 'user' | 'assistant'; content: string; timestamp: Date }>;
  relevantMemories: Memory[];
  userProfile: UserProfile;
}

export interface UserProfile {
  userId: number;
  name: string;
  preferences: Record<string, any>;
  communicationStyle: 'formal' | 'casual' | 'technical';
  timezone: string;
  language: string;
}

// Mock Vector Database - في الإنتاج سيتم استبدالها بـ Pinecone أو Weaviate
class MemorySystem {
  private memories: Map<number, Memory[]> = new Map();
  private userProfiles: Map<number, UserProfile> = new Map();
  private conversationHistory: Map<number, ConversationContext['recentMessages']> = new Map();

  // إضافة ذاكرة جديدة
  addMemory(memory: Omit<Memory, 'id' | 'timestamp'>): Memory {
    const newMemory: Memory = {
      ...memory,
      id: `mem_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
    };

    if (!this.memories.has(memory.userId)) {
      this.memories.set(memory.userId, []);
    }

    this.memories.get(memory.userId)!.push(newMemory);
    return newMemory;
  }

  // البحث عن ذاكرة ذات صلة
  searchMemories(userId: number, query: string, limit: number = 5): Memory[] {
    const userMemories = this.memories.get(userId) || [];

    // محاكاة البحث - في الإنتاج سيتم استخدام Vector Similarity
    return userMemories
      .filter(mem => {
        const queryLower = query.toLowerCase();
        return (
          mem.content.toLowerCase().includes(queryLower) ||
          mem.tags.some(tag => tag.toLowerCase().includes(queryLower))
        );
      })
      .sort((a, b) => b.importance - a.importance)
      .slice(0, limit);
  }

  // الحصول على السياق الكامل للمحادثة
  getConversationContext(userId: number): ConversationContext {
    return {
      userId,
      recentMessages: this.conversationHistory.get(userId) || [],
      relevantMemories: this.searchMemories(userId, '', 10),
      userProfile: this.getUserProfile(userId),
    };
  }

  // إضافة رسالة للمحادثة
  addMessage(userId: number, role: 'user' | 'assistant', content: string): void {
    if (!this.conversationHistory.has(userId)) {
      this.conversationHistory.set(userId, []);
    }

    this.conversationHistory.get(userId)!.push({
      role,
      content,
      timestamp: new Date(),
    });

    // الاحتفاظ بآخر 50 رسالة فقط
    const messages = this.conversationHistory.get(userId)!;
    if (messages.length > 50) {
      messages.shift();
    }
  }

  // إنشاء أو تحديث ملف تعريف المستخدم
  setUserProfile(profile: UserProfile): void {
    this.userProfiles.set(profile.userId, profile);
  }

  // الحصول على ملف تعريف المستخدم
  getUserProfile(userId: number): UserProfile {
    return (
      this.userProfiles.get(userId) || {
        userId,
        name: 'مستخدم',
        preferences: {},
        communicationStyle: 'casual',
        timezone: 'Africa/Cairo',
        language: 'ar',
      }
    );
  }

  // تحديث تفضيلات المستخدم
  updatePreferences(userId: number, preferences: Record<string, any>): void {
    const profile = this.getUserProfile(userId);
    profile.preferences = { ...profile.preferences, ...preferences };
    this.setUserProfile(profile);
  }

  // حذف ذاكرة قديمة (تنظيف)
  cleanOldMemories(userId: number, daysOld: number = 30): number {
    const userMemories = this.memories.get(userId) || [];
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);

    const initialLength = userMemories.length;
    const filtered = userMemories.filter(mem => mem.timestamp > cutoffDate);

    this.memories.set(userId, filtered);
    return initialLength - filtered.length;
  }

  // الحصول على إحصائيات الذاكرة
  getMemoryStats(userId: number): {
    totalMemories: number;
    byCategory: Record<string, number>;
    averageImportance: number;
  } {
    const userMemories = this.memories.get(userId) || [];

    const byCategory: Record<string, number> = {
      task: 0,
      preference: 0,
      fact: 0,
      interaction: 0,
      financial: 0,
      medical: 0,
    };

    userMemories.forEach(mem => {
      byCategory[mem.category]++;
    });

    const averageImportance =
      userMemories.length > 0
        ? userMemories.reduce((sum, mem) => sum + mem.importance, 0) / userMemories.length
        : 0;

    return {
      totalMemories: userMemories.length,
      byCategory,
      averageImportance,
    };
  }

  // تصدير الذاكرة (للنسخ الاحتياطي)
  exportMemories(userId: number): Memory[] {
    return this.memories.get(userId) || [];
  }

  // استيراد الذاكرة (من النسخة الاحتياطية)
  importMemories(userId: number, memories: Memory[]): void {
    this.memories.set(userId, memories);
  }
}

// Singleton instance
export const memorySystem = new MemorySystem();

// Dummy data للاختبار
export function initializeDummyMemories(userId: number): void {
  memorySystem.addMemory({
    userId,
    content: 'المستخدم يفضل الاجتماعات في الصباح',
    importance: 0.8,
    category: 'preference',
    tags: ['اجتماعات', 'وقت'],
  });

  memorySystem.addMemory({
    userId,
    content: 'لديه 10 مراكز طبية في مصر',
    importance: 0.9,
    category: 'fact',
    tags: ['مراكز', 'طبية'],
  });

  memorySystem.addMemory({
    userId,
    content: 'يستخدم فودافون كاش للمعاملات المالية',
    importance: 0.7,
    category: 'financial',
    tags: ['دفع', 'فودافون'],
  });

  memorySystem.setUserProfile({
    userId,
    name: 'أحمد عبد الرحيم',
    preferences: {
      theme: 'dark',
      language: 'ar',
      notifications: true,
    },
    communicationStyle: 'formal',
    timezone: 'Africa/Cairo',
    language: 'ar',
  });
}
