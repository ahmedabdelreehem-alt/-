import React, { useState, useEffect } from 'react';
import { Mic, Volume2, Settings } from 'lucide-react';

interface AvatarAssistantProps {
  isListening?: boolean;
  isProcessing?: boolean;
  onMicClick?: () => void;
}

export default function AvatarAssistant({
  isListening = false,
  isProcessing = false,
  onMicClick = () => {},
}: AvatarAssistantProps) {
  const [blinkState, setBlinkState] = useState(false);
  const [mouthState, setMouthState] = useState(0);
  const [glowIntensity, setGlowIntensity] = useState(1);

  // Blinking animation
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlinkState((prev) => !prev);
    }, 3000);
    return () => clearInterval(blinkInterval);
  }, []);

  // Mouth animation when listening
  useEffect(() => {
    if (!isListening && !isProcessing) return;

    const mouthInterval = setInterval(() => {
      setMouthState((prev) => (prev + 1) % 4);
    }, 150);
    return () => clearInterval(mouthInterval);
  }, [isListening, isProcessing]);

  // Glow animation when processing
  useEffect(() => {
    if (!isProcessing) {
      setGlowIntensity(1);
      return;
    }

    const glowInterval = setInterval(() => {
      setGlowIntensity((prev) => (prev === 1 ? 1.5 : 1));
    }, 600);
    return () => clearInterval(glowInterval);
  }, [isProcessing]);

  return (
    <div className="flex flex-col items-center justify-center gap-8 py-12">
      {/* Avatar Container */}
      <div className="relative w-64 h-64 flex items-center justify-center">
        {/* Glow Background */}
        <div
          className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-600/30 to-violet-600/30 blur-3xl transition-all duration-500"
          style={{
            opacity: isProcessing ? glowIntensity * 0.5 : 0.3,
            transform: `scale(${isProcessing ? 1.2 : 1})`,
          }}
        />

        {/* Avatar SVG */}
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full relative z-10"
          style={{
            filter: isProcessing ? `drop-shadow(0 0 ${20 * glowIntensity}px rgba(168, 85, 247, 0.6))` : 'drop-shadow(0 0 10px rgba(168, 85, 247, 0.3))',
          }}
        >
          {/* Head */}
          <circle cx="100" cy="100" r="70" fill="url(#headGradient)" stroke="rgba(168, 85, 247, 0.5)" strokeWidth="2" />

          {/* Left Eye */}
          <circle cx="80" cy="85" r="12" fill="rgba(255, 255, 255, 0.9)" />
          <circle
            cx="80"
            cy="85"
            r="8"
            fill="rgba(124, 58, 237, 0.8)"
            style={{
              transform: blinkState ? 'scaleY(0.1)' : 'scaleY(1)',
              transformOrigin: '50% 50%',
              transition: 'transform 0.2s ease',
            }}
          />
          <circle cx="82" cy="83" r="3" fill="rgba(255, 255, 255, 0.9)" />

          {/* Right Eye */}
          <circle cx="120" cy="85" r="12" fill="rgba(255, 255, 255, 0.9)" />
          <circle
            cx="120"
            cy="85"
            r="8"
            fill="rgba(124, 58, 237, 0.8)"
            style={{
              transform: blinkState ? 'scaleY(0.1)' : 'scaleY(1)',
              transformOrigin: '50% 50%',
              transition: 'transform 0.2s ease',
            }}
          />
          <circle cx="122" cy="83" r="3" fill="rgba(255, 255, 255, 0.9)" />

          {/* Mouth - Animated */}
          {mouthState === 0 && (
            <path d="M 85 120 Q 100 125 115 120" stroke="rgba(168, 85, 247, 0.8)" strokeWidth="2" fill="none" strokeLinecap="round" />
          )}
          {mouthState === 1 && (
            <path d="M 85 120 Q 100 128 115 120" stroke="rgba(168, 85, 247, 0.8)" strokeWidth="2" fill="none" strokeLinecap="round" />
          )}
          {mouthState === 2 && (
            <ellipse cx="100" cy="122" rx="8" ry="10" fill="rgba(168, 85, 247, 0.4)" />
          )}
          {mouthState === 3 && (
            <path d="M 85 120 Q 100 130 115 120" stroke="rgba(168, 85, 247, 0.8)" strokeWidth="2" fill="none" strokeLinecap="round" />
          )}

          {/* Gradients */}
          <defs>
            <linearGradient id="headGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(168, 85, 247, 0.9)" />
              <stop offset="100%" stopColor="rgba(124, 58, 237, 0.8)" />
            </linearGradient>
          </defs>
        </svg>

        {/* Status Indicator */}
        {isListening && (
          <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-green-500/20 px-3 py-1 rounded-full border border-green-500/50">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs text-green-300 font-medium">استمع</span>
          </div>
        )}

        {isProcessing && (
          <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-purple-500/20 px-3 py-1 rounded-full border border-purple-500/50">
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
            <span className="text-xs text-purple-300 font-medium">معالجة</span>
          </div>
        )}
      </div>

      {/* Control Buttons */}
      <div className="flex gap-4 items-center justify-center">
        {/* Microphone Button */}
        <button
          onClick={onMicClick}
          className={`relative p-4 rounded-full transition-all duration-300 ${
            isListening
              ? 'bg-gradient-to-r from-green-500 to-emerald-500 shadow-lg shadow-green-500/50'
              : 'bg-gradient-to-r from-purple-600 to-violet-600 hover:shadow-lg hover:shadow-purple-500/50'
          }`}
        >
          <Mic className="w-6 h-6 text-white" />
          {isListening && (
            <div className="absolute inset-0 rounded-full border-2 border-green-300 animate-pulse" />
          )}
        </button>

        {/* Volume Button */}
        <button className="p-4 rounded-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:shadow-lg hover:shadow-blue-500/50 transition-all duration-300">
          <Volume2 className="w-6 h-6 text-white" />
        </button>

        {/* Settings Button */}
        <button className="p-4 rounded-full bg-gradient-to-r from-slate-600 to-slate-700 hover:shadow-lg hover:shadow-slate-500/50 transition-all duration-300">
          <Settings className="w-6 h-6 text-white" />
        </button>
      </div>

      {/* Status Text */}
      <div className="text-center">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-violet-400 bg-clip-text text-transparent">
          مساعدك الشخصي الذكي
        </h2>
        <p className="text-sm text-slate-400 mt-2">
          {isListening ? 'جاهز للاستماع إلى أوامرك...' : isProcessing ? 'جاري معالجة طلبك...' : 'اضغط الميكروفون للبدء'}
        </p>
      </div>
    </div>
  );
}
