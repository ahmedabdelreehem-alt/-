import { TRPCError } from '@trpc/server';
import { sanitizeInput, rateLimitKey } from './security';
import type { TrpcContext } from './context';

const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const RATE_LIMIT_MAX_REQUESTS = 100;

export function checkRateLimit(userId: number, action: string): boolean {
  const key = rateLimitKey(userId, action);
  const now = Date.now();

  const limit = rateLimitMap.get(key);

  if (!limit || now > limit.resetTime) {
    rateLimitMap.set(key, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return true;
  }

  if (limit.count >= RATE_LIMIT_MAX_REQUESTS) {
    throw new TRPCError({
      code: 'TOO_MANY_REQUESTS',
      message: 'Rate limit exceeded. Please try again later.',
    });
  }

  limit.count++;
  return true;
}

export function validateInput(input: any): any {
  if (typeof input === 'string') {
    return sanitizeInput(input);
  }

  if (typeof input === 'object' && input !== null) {
    const sanitized: any = {};
    for (const [key, value] of Object.entries(input)) {
      sanitized[key] = validateInput(value);
    }
    return sanitized;
  }

  return input;
}

export function requireAdmin(ctx: TrpcContext): void {
  if (!ctx.user || ctx.user.role !== 'admin') {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Admin access required',
    });
  }
}

export function requireAuth(ctx: TrpcContext): void {
  if (!ctx.user) {
    throw new TRPCError({
      code: 'UNAUTHORIZED',
      message: 'Authentication required',
    });
  }
}

export function logSecurityEvent(
  userId: number,
  action: string,
  details: Record<string, any>,
  severity: 'info' | 'warning' | 'error' = 'info'
): void {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    userId,
    action,
    details,
    severity,
  };

  if (severity === 'error') {
    console.error('[SECURITY]', JSON.stringify(logEntry));
  } else if (severity === 'warning') {
    console.warn('[SECURITY]', JSON.stringify(logEntry));
  } else {
    console.log('[SECURITY]', JSON.stringify(logEntry));
  }
}

export function validateApiKey(apiKey: string): boolean {
  const validKeys = (process.env.VALID_API_KEYS || '').split(',');
  return validKeys.includes(apiKey);
}

export function generateApiKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 32; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `sk_${result}`;
}
