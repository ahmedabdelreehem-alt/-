import { describe, expect, it } from 'vitest';
import { adminRouter } from './admin';
import { TRPCError } from '@trpc/server';
import type { TrpcContext } from '../_core/context';

type AuthenticatedUser = NonNullable<TrpcContext['user']>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: 'admin-user',
    email: 'admin@example.com',
    name: 'Admin User',
    loginMethod: 'test',
    role: 'admin',
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: 'https',
      headers: {},
    } as TrpcContext['req'],
    res: {} as TrpcContext['res'],
  };
}

function createUserContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 2,
    openId: 'regular-user',
    email: 'user@example.com',
    name: 'Regular User',
    loginMethod: 'test',
    role: 'user',
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: 'https',
      headers: {},
    } as TrpcContext['req'],
    res: {} as TrpcContext['res'],
  };
}

describe('Admin Router', () => {
  it('should get users as admin', async () => {
    const ctx = createAdminContext();
    const caller = adminRouter.createCaller(ctx);

    const result = await caller.getUsers();

    expect(Array.isArray(result.users)).toBe(true);
    expect(result.users.length).toBeGreaterThan(0);
    expect(result.users[0]).toHaveProperty('id');
    expect(result.users[0]).toHaveProperty('role');
  });

  it('should deny access to non-admin users', async () => {
    const ctx = createUserContext();
    const caller = adminRouter.createCaller(ctx);

    try {
      await caller.getUsers();
      expect.fail('Should have thrown FORBIDDEN error');
    } catch (error: any) {
      expect(error.code).toBe('FORBIDDEN');
    }
  });

  it('should update user role as admin', async () => {
    const ctx = createAdminContext();
    const caller = adminRouter.createCaller(ctx);

    const result = await caller.updateUserRole({
      userId: 2,
      role: 'admin',
    });

    expect(result.success).toBe(true);
    expect(result.userId).toBe(2);
    expect(result.newRole).toBe('admin');
  });

  it('should get system status as admin', async () => {
    const ctx = createAdminContext();
    const caller = adminRouter.createCaller(ctx);

    const result = await caller.getSystemStatus();

    expect(result.status).toBe('operational');
    expect(result.services).toBeDefined();
    expect(result.metrics).toBeDefined();
    expect(result.metrics.activeUsers).toBeGreaterThanOrEqual(0);
  });

  it('should control services as admin', async () => {
    const ctx = createAdminContext();
    const caller = adminRouter.createCaller(ctx);

    const result = await caller.controlService({
      service: 'chat',
      action: 'restart',
    });

    expect(result.success).toBe(true);
    expect(result.service).toBe('chat');
    expect(result.action).toBe('restart');
  });

  it('should update settings as admin', async () => {
    const ctx = createAdminContext();
    const caller = adminRouter.createCaller(ctx);

    const result = await caller.updateSettings({
      key: 'maintenance_mode',
      value: true,
    });

    expect(result.success).toBe(true);
    expect(result.setting).toBe('maintenance_mode');
    expect(result.newValue).toBe(true);
  });

  it('should get audit log as admin', async () => {
    const ctx = createAdminContext();
    const caller = adminRouter.createCaller(ctx);

    const result = await caller.getAuditLog({ limit: 50 });

    expect(Array.isArray(result.logs)).toBe(true);
    if (result.logs.length > 0) {
      expect(result.logs[0]).toHaveProperty('id');
      expect(result.logs[0]).toHaveProperty('action');
      expect(result.logs[0]).toHaveProperty('timestamp');
    }
  });

  it('should deny service control to non-admin', async () => {
    const ctx = createUserContext();
    const caller = adminRouter.createCaller(ctx);

    try {
      await caller.controlService({
        service: 'chat',
        action: 'restart',
      });
      expect.fail('Should have thrown FORBIDDEN error');
    } catch (error: any) {
      expect(error.code).toBe('FORBIDDEN');
    }
  });
});
