export type AgentType =
  | 'main'
  | 'customer_service'
  | 'financial_auditor'
  | 'content_creator'
  | 'scheduler'
  | 'data_analyst';

export interface Agent {
  id: string;
  type: AgentType;
  name: string;
  description: string;
  capabilities: string[];
  status: 'active' | 'inactive' | 'busy';
  createdAt: Date;
  lastActivity: Date;
}

export interface AgentTask {
  id: string;
  agentId: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  createdAt: Date;
  completedAt?: Date;
  result?: any;
  error?: string;
}

export interface AgentResponse {
  agentId: string;
  agentName: string;
  message: string;
  data?: any;
  suggestedActions?: string[];
}

class MultiAgentSystem {
  private agents: Map<string, Agent> = new Map();
  private tasks: Map<string, AgentTask[]> = new Map();
  private mainAgentId: string = '';

  constructor() {
    this.initializeDefaultAgents();
  }

  private initializeDefaultAgents(): void {
    // Main Avatar Agent
    this.createAgent({
      type: 'main',
      name: 'المساعد الرئيسي',
      description: 'المساعد الذكي الرئيسي الذي يدير جميع العمليات',
      capabilities: [
        'معالجة الأوامر',
        'إدارة المهام',
        'التواصل مع المستخدم',
        'تنسيق الوكلاء الآخرين',
      ],
    });

    // Customer Service Agent
    this.createAgent({
      type: 'customer_service',
      name: 'وكيل خدمة العملاء',
      description: 'متخصص في التعامل مع استفسارات العملاء والدعم',
      capabilities: [
        'الرد على الاستفسارات',
        'حل المشاكل',
        'إدارة الشكاوى',
        'تقديم الدعم',
      ],
    });

    // Financial Auditor Agent
    this.createAgent({
      type: 'financial_auditor',
      name: 'وكيل التدقيق المالي',
      description: 'متخصص في تحليل البيانات المالية والتقارير',
      capabilities: [
        'تحليل المعاملات',
        'إعداد التقارير المالية',
        'التنبؤ بالاتجاهات',
        'تدقيق الحسابات',
      ],
    });

    // Content Creator Agent
    this.createAgent({
      type: 'content_creator',
      name: 'وكيل إنشاء المحتوى',
      description: 'متخصص في إنشاء ومشاركة المحتوى على وسائل التواصل',
      capabilities: [
        'إنشاء منشورات',
        'تحرير الصور',
        'جدولة المحتوى',
        'تحليل الأداء',
      ],
    });

    // Scheduler Agent
    this.createAgent({
      type: 'scheduler',
      name: 'وكيل الجدولة',
      description: 'متخصص في إدارة المهام والمواعيد',
      capabilities: [
        'جدولة المهام',
        'تذكيرات',
        'إدارة الوقت',
        'تحسين الإنتاجية',
      ],
    });

    // Data Analyst Agent
    this.createAgent({
      type: 'data_analyst',
      name: 'وكيل تحليل البيانات',
      description: 'متخصص في تحليل البيانات والإحصائيات',
      capabilities: [
        'تحليل البيانات',
        'إنشاء رسوم بيانية',
        'استخراج الرؤى',
        'التنبؤات',
      ],
    });
  }

  // إنشاء وكيل جديد
  private createAgent(agent: Omit<Agent, 'id' | 'createdAt' | 'lastActivity' | 'status'>): Agent {
    const newAgent: Agent = {
      ...agent,
      id: `agent_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      status: 'active',
      createdAt: new Date(),
      lastActivity: new Date(),
    };

    this.agents.set(newAgent.id, newAgent);

    if (agent.type === 'main') {
      this.mainAgentId = newAgent.id;
    }

    return newAgent;
  }

  // الحصول على جميع الوكلاء
  getAgents(): Agent[] {
    return Array.from(this.agents.values());
  }

  // الحصول على وكيل محدد
  getAgent(agentId: string): Agent | undefined {
    return this.agents.get(agentId);
  }

  // الحصول على الوكيل الرئيسي
  getMainAgent(): Agent | undefined {
    return this.agents.get(this.mainAgentId);
  }

  // تعيين مهمة لوكيل
  assignTask(agentId: string, task: Omit<AgentTask, 'id' | 'createdAt' | 'status' | 'agentId'>): AgentTask {
    const newTask: AgentTask = {
      ...task,
      agentId,
      id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      status: 'pending',
      createdAt: new Date(),
    };

    if (!this.tasks.has(agentId)) {
      this.tasks.set(agentId, []);
    }

    this.tasks.get(agentId)!.push(newTask);

    // تحديث حالة الوكيل
    const agent = this.agents.get(agentId);
    if (agent) {
      agent.status = 'busy';
      agent.lastActivity = new Date();
    }

    return newTask;
  }

  // الحصول على مهام الوكيل
  getAgentTasks(agentId: string, status?: string): AgentTask[] {
    const tasks = this.tasks.get(agentId) || [];
    if (status) {
      return tasks.filter(t => t.status === status);
    }
    return tasks;
  }

  // تحديث حالة المهمة
  updateTaskStatus(
    agentId: string,
    taskId: string,
    status: AgentTask['status'],
    result?: any,
    error?: string
  ): AgentTask | undefined {
    const tasks = this.tasks.get(agentId);
    if (!tasks) return undefined;

    const task = tasks.find(t => t.id === taskId);
    if (!task) return undefined;

    task.status = status;
    if (result) task.result = result;
    if (error) task.error = error;
    if (status === 'completed' || status === 'failed') {
      task.completedAt = new Date();

      // تحديث حالة الوكيل
      const agent = this.agents.get(agentId);
      if (agent) {
        agent.status = 'active';
        agent.lastActivity = new Date();
      }
    }

    return task;
  }

  // معالجة الأمر من خلال الوكيل الرئيسي
  async processCommand(command: string): Promise<AgentResponse> {
    const mainAgent = this.getMainAgent();
    if (!mainAgent) {
      return {
        agentId: '',
        agentName: 'Unknown',
        message: 'الوكيل الرئيسي غير متاح',
      };
    }

    // تحديد الوكيل المناسب بناءً على الأمر
    let targetAgent = mainAgent;

    if (
      command.includes('مالي') ||
      command.includes('حساب') ||
      command.includes('معاملة')
    ) {
      const financialAgent = Array.from(this.agents.values()).find(
        a => a.type === 'financial_auditor'
      );
      if (financialAgent) targetAgent = financialAgent;
    } else if (
      command.includes('محتوى') ||
      command.includes('منشور') ||
      command.includes('فيسبوك')
    ) {
      const contentAgent = Array.from(this.agents.values()).find(
        a => a.type === 'content_creator'
      );
      if (contentAgent) targetAgent = contentAgent;
    } else if (
      command.includes('مهمة') ||
      command.includes('موعد') ||
      command.includes('جدول')
    ) {
      const schedulerAgent = Array.from(this.agents.values()).find(
        a => a.type === 'scheduler'
      );
      if (schedulerAgent) targetAgent = schedulerAgent;
    }

    // تعيين المهمة
    const task = this.assignTask(targetAgent.id, {
      title: command,
      description: `معالجة الأمر: ${command}`,
      priority: 'high',
    });

    // محاكاة معالجة المهمة
    setTimeout(() => {
      this.updateTaskStatus(targetAgent.id, task.id, 'completed', {
        processed: true,
        timestamp: new Date(),
      });
    }, 1000);

    return {
      agentId: targetAgent.id,
      agentName: targetAgent.name,
      message: `تم تعيين المهمة للوكيل: ${targetAgent.name}`,
      suggestedActions: targetAgent.capabilities,
    };
  }

  // الحصول على إحصائيات النظام
  getSystemStatistics(): {
    totalAgents: number;
    activeAgents: number;
    totalTasks: number;
    completedTasks: number;
    pendingTasks: number;
  } {
    const agents = Array.from(this.agents.values());
    const allTasks = Array.from(this.tasks.values()).flat();

    return {
      totalAgents: agents.length,
      activeAgents: agents.filter(a => a.status === 'active').length,
      totalTasks: allTasks.length,
      completedTasks: allTasks.filter(t => t.status === 'completed').length,
      pendingTasks: allTasks.filter(t => t.status === 'pending').length,
    };
  }
}

export const multiAgentSystem = new MultiAgentSystem();
