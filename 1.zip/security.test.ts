import { describe, expect, it } from 'vitest';
import {
  generateToken,
  verifyToken,
  encryptData,
  decryptData,
  hashPassword,
  verifyPassword,
  generateSecureToken,
  sanitizeInput,
  validateEmail,
} from './security';

describe('Security Module', () => {
  it('should generate and verify JWT tokens', async () => {
    const payload = { userId: 1, email: 'test@example.com' };
    const token = await generateToken(payload, '24h');

    expect(token).toBeDefined();
    expect(typeof token).toBe('string');

    const verified = await verifyToken(token);
    expect(verified).toBeDefined();
    expect(verified?.userId).toBe(1);
    expect(verified?.email).toBe('test@example.com');
  });


  it('should reject invalid tokens', async () => {
    const verified = await verifyToken('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.invalid.invalid');
    expect(verified).toBeNull();
  });

  it('should encrypt and decrypt data', () => {
    const originalData = 'sensitive information';
    const encrypted = encryptData(originalData);

    expect(encrypted).not.toBe(originalData);
    expect(encrypted).toContain(':');

    const decrypted = decryptData(encrypted);
    expect(decrypted).toBe(originalData);
  });

  it('should hash and verify passwords', () => {
    const password = 'MySecurePassword123!';
    const hash = hashPassword(password);

    expect(hash).not.toBe(password);
    expect(verifyPassword(password, hash)).toBe(true);
    expect(verifyPassword('WrongPassword', hash)).toBe(false);
  });

  it('should generate secure tokens', () => {
    const token1 = generateSecureToken(32);
    const token2 = generateSecureToken(32);

    expect(token1).toBeDefined();
    expect(token2).toBeDefined();
    expect(token1).not.toBe(token2);
    expect(token1.length).toBe(64); // 32 bytes = 64 hex chars
  });

  it('should sanitize input', () => {
    const maliciousInput = '<script>alert("xss")</script>';
    const sanitized = sanitizeInput(maliciousInput);

    expect(sanitized).not.toContain('<');
    expect(sanitized).not.toContain('>');
    expect(sanitized).not.toContain('script');
  });

  it('should remove javascript: protocol', () => {
    const input = 'javascript:alert("xss")';
    const sanitized = sanitizeInput(input);

    expect(sanitized).not.toContain('javascript:');
  });

  it('should remove event handlers', () => {
    const input = 'onclick=alert("xss")';
    const sanitized = sanitizeInput(input);

    expect(sanitized).not.toContain('onclick=');
  });

  it('should validate emails', () => {
    expect(validateEmail('test@example.com')).toBe(true);
    expect(validateEmail('user.name@domain.co.uk')).toBe(true);
    expect(validateEmail('invalid.email')).toBe(false);
    expect(validateEmail('missing@domain')).toBe(false);
    expect(validateEmail('@example.com')).toBe(false);
  });

  it('should trim input', () => {
    const input = '  hello world  ';
    const sanitized = sanitizeInput(input);

    expect(sanitized).toBe('hello world');
  });
});
