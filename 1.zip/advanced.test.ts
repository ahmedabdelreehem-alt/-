import { describe, it, expect, beforeEach } from 'vitest';
import { memorySystem, initializeDummyMemories } from './memorySystem';
import { financialSystem, initializeDummyFinancialData } from './financialSystem';
import { medicalCentersSystem, initializeDummyMedicalData } from './medicalCentersSystem';
import { multiAgentSystem } from './multiAgentSystem';

const TEST_USER_ID = 999;

describe('Advanced Systems', () => {
  beforeEach(() => {
    // Initialize dummy data for testing
    initializeDummyMemories(TEST_USER_ID);
    initializeDummyFinancialData(TEST_USER_ID);
    initializeDummyMedicalData(TEST_USER_ID);
  });

  describe('Memory System', () => {
    it('should add memory successfully', () => {
      const memory = memorySystem.addMemory({
        userId: TEST_USER_ID,
        content: 'Test memory',
        importance: 0.8,
        category: 'test',
        tags: ['test'],
      });

      expect(memory).toBeDefined();
      expect(memory.content).toBe('Test memory');
      expect(memory.importance).toBe(0.8);
    });

    it('should search memories', () => {
      const results = memorySystem.searchMemories(TEST_USER_ID, 'test', 10);
      expect(Array.isArray(results)).toBe(true);
    });

    it('should get conversation context', () => {
      const context = memorySystem.getConversationContext(TEST_USER_ID);
      expect(context).toBeDefined();
      expect(context.recentMessages).toBeDefined();
      expect(context.userProfile).toBeDefined();
      expect(context.userProfile.preferences).toBeDefined();
    });

    it('should update preferences', () => {
      const newPrefs = { language: 'ar', theme: 'dark' };
      memorySystem.updatePreferences(TEST_USER_ID, newPrefs);

      const context = memorySystem.getConversationContext(TEST_USER_ID);
      expect(context.userProfile.preferences.language).toBe('ar');
      expect(context.userProfile.preferences.theme).toBe('dark');
    });
  });

  describe('Financial System', () => {
    it('should create account', () => {
      const account = financialSystem.createAccount({
        userId: TEST_USER_ID,
        name: 'Test Account',
        balance: 10000,
        currency: 'EGP',
        type: 'savings',
      });

      expect(account).toBeDefined();
      expect(account.name).toBe('Test Account');
      expect(account.balance).toBe(10000);
    });

    it('should add transaction', () => {
      const transaction = financialSystem.addTransaction({
        userId: TEST_USER_ID,
        type: 'income',
        amount: 5000,
        currency: 'EGP',
        description: 'Test transaction',
        status: 'completed',
        category: 'salary',
        paymentMethod: 'bank_transfer',
      });

      expect(transaction).toBeDefined();
      expect(transaction.amount).toBe(5000);
      expect(transaction.type).toBe('income');
    });

    it('should generate financial report', () => {
      const report = financialSystem.generateReport(TEST_USER_ID, 'monthly');

      expect(report).toBeDefined();
      expect(report.period).toBe('monthly');
      expect(report.totalIncome).toBeGreaterThanOrEqual(0);
      expect(report.totalExpense).toBeGreaterThanOrEqual(0);
    });

    it('should get financial statistics', () => {
      const stats = financialSystem.getStatistics(TEST_USER_ID);

      expect(stats).toBeDefined();
      expect(stats.totalBalance).toBeGreaterThanOrEqual(0);
      expect(stats.totalTransactions).toBeGreaterThanOrEqual(0);
      expect(Array.isArray(stats.topCategories)).toBe(true);
    });
  });

  describe('Medical Centers System', () => {
    it('should get medical centers', () => {
      const centers = medicalCentersSystem.getCenters(TEST_USER_ID);

      expect(Array.isArray(centers)).toBe(true);
      expect(centers.length).toBeGreaterThan(0);
    });

    it('should get center statistics', () => {
      const centers = medicalCentersSystem.getCenters(TEST_USER_ID);
      if (centers.length > 0) {
        const stats = medicalCentersSystem.getCenterStatistics(centers[0].id);

        expect(stats).toBeDefined();
        expect(stats.totalStaff).toBeGreaterThanOrEqual(0);
        expect(stats.totalPatients).toBeGreaterThanOrEqual(0);
        expect(stats.occupancyRate).toBeGreaterThanOrEqual(0);
      }
    });

    it('should get all centers report', () => {
      const report = medicalCentersSystem.getAllCentersReport(TEST_USER_ID);

      expect(report).toBeDefined();
      expect(report.totalCenters).toBeGreaterThan(0);
      expect(report.totalStaff).toBeGreaterThanOrEqual(0);
      expect(report.totalPatients).toBeGreaterThanOrEqual(0);
      expect(Array.isArray(report.centers)).toBe(true);
    });

    it('should get center patients', () => {
      const centers = medicalCentersSystem.getCenters(TEST_USER_ID);
      if (centers.length > 0) {
        const patients = medicalCentersSystem.getPatients(centers[0].id);

        expect(Array.isArray(patients)).toBe(true);
        expect(patients.length).toBeGreaterThanOrEqual(0);
      }
    });

    it('should get center staff', () => {
      const centers = medicalCentersSystem.getCenters(TEST_USER_ID);
      if (centers.length > 0) {
        const staff = medicalCentersSystem.getStaff(centers[0].id);

        expect(Array.isArray(staff)).toBe(true);
        expect(staff.length).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe('Multi-Agent System', () => {
    it('should get agents', () => {
      const agents = multiAgentSystem.getAgents();

      expect(Array.isArray(agents)).toBe(true);
      expect(agents.length).toBeGreaterThan(0);
    });

    it('should get main agent', () => {
      const mainAgent = multiAgentSystem.getMainAgent();

      expect(mainAgent).toBeDefined();
      expect(mainAgent?.type).toBe('main');
    });

    it('should process command', async () => {
      const response = await multiAgentSystem.processCommand('اعرض لي التقرير المالي');

      expect(response).toBeDefined();
      expect(response.agentId).toBeDefined();
      expect(response.agentName).toBeDefined();
      expect(response.message).toBeDefined();
    });

    it('should get system statistics', () => {
      const stats = multiAgentSystem.getSystemStatistics();

      expect(stats).toBeDefined();
      expect(stats.totalAgents).toBeGreaterThan(0);
      expect(stats.activeAgents).toBeGreaterThanOrEqual(0);
      expect(stats.totalTasks).toBeGreaterThanOrEqual(0);
    });

    it('should assign task to agent', () => {
      const agents = multiAgentSystem.getAgents();
      if (agents.length > 0) {
        const task = multiAgentSystem.assignTask(agents[0].id, {
          title: 'Test Task',
          description: 'Test task description',
          priority: 'high',
        });

        expect(task).toBeDefined();
        expect(task.title).toBe('Test Task');
        expect(task.status).toBe('pending');
      }
    });

    it('should update task status', () => {
      const agents = multiAgentSystem.getAgents();
      if (agents.length > 0) {
        const task = multiAgentSystem.assignTask(agents[0].id, {
          title: 'Test Task',
          description: 'Test task description',
          priority: 'high',
        });

        const updated = multiAgentSystem.updateTaskStatus(
          agents[0].id,
          task.id,
          'completed',
          { result: 'success' }
        );

        expect(updated).toBeDefined();
        expect(updated?.status).toBe('completed');
        expect(updated?.result).toBeDefined();
      }
    });
  });
});
