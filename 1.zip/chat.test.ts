import { describe, expect, it } from 'vitest';
import { chatRouter } from './chat';
import type { TrpcContext } from '../_core/context';

type AuthenticatedUser = NonNullable<TrpcContext['user']>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: 'test-user',
    email: 'test@example.com',
    name: 'Test User',
    loginMethod: 'test',
    role: 'user',
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: 'https',
      headers: {},
    } as TrpcContext['req'],
    res: {} as TrpcContext['res'],
  };
}

describe('Chat Router', () => {
  it('should send a message successfully', async () => {
    const ctx = createAuthContext();
    const caller = chatRouter.createCaller(ctx);

    const result = await caller.sendMessage({
      text: 'Hello, assistant!',
    });

    expect(result.success).toBe(true);
    expect(result.sender).toBe('user');
    expect(result.text).toBe('Hello, assistant!');
    expect(result.messageId).toBeDefined();
    expect(result.conversationId).toBeDefined();
  });

  it('should get chat history', async () => {
    const ctx = createAuthContext();
    const caller = chatRouter.createCaller(ctx);

    const result = await caller.getHistory({});

    expect(result.conversationId).toBeDefined();
    expect(Array.isArray(result.messages)).toBe(true);
    expect(result.messages.length).toBeGreaterThan(0);
  });

  it('should transcribe audio', async () => {
    const ctx = createAuthContext();
    const caller = chatRouter.createCaller(ctx);

    const result = await caller.transcribeAudio({
      audioData: 'base64encodedaudio',
      language: 'en',
    });

    expect(result.success).toBe(true);
    expect(result.text).toBeDefined();
    expect(result.confidence).toBeGreaterThan(0);
    expect(result.confidence).toBeLessThanOrEqual(1);
  });

  it('should synthesize speech', async () => {
    const ctx = createAuthContext();
    const caller = chatRouter.createCaller(ctx);

    const result = await caller.synthesizeSpeech({
      text: 'Hello world',
    });

    expect(result.success).toBe(true);
    expect(result.audioUrl).toBeDefined();
    expect(result.duration).toBeGreaterThan(0);
  });

  it('should process commands', async () => {
    const ctx = createAuthContext();
    const caller = chatRouter.createCaller(ctx);

    const result = await caller.processCommand({
      command: 'set_reminder',
      params: { time: '10:00', message: 'Meeting' },
    });

    expect(result.success).toBe(true);
    expect(result.command).toBe('set_reminder');
    expect(result.result).toBeDefined();
  });

  it('should validate message length', async () => {
    const ctx = createAuthContext();
    const caller = chatRouter.createCaller(ctx);

    try {
      await caller.sendMessage({
        text: '',
      });
      expect.fail('Should have thrown validation error');
    } catch (error: any) {
      expect(error.code).toBe('BAD_REQUEST');
    }
  });
});
