export interface Transaction {
  id: string;
  userId: number;
  type: 'income' | 'expense' | 'transfer';
  amount: number;
  currency: string;
  description: string;
  timestamp: Date;
  status: 'pending' | 'completed' | 'failed';
  category: string;
  paymentMethod: string;
}

export interface Account {
  id: string;
  userId: number;
  name: string;
  balance: number;
  currency: string;
  type: 'savings' | 'checking' | 'business';
  createdAt: Date;
}

export interface FinancialReport {
  userId: number;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly';
  totalIncome: number;
  totalExpense: number;
  netProfit: number;
  transactions: Transaction[];
  generatedAt: Date;
}

class FinancialSystem {
  private transactions: Map<number, Transaction[]> = new Map();
  private accounts: Map<number, Account[]> = new Map();

  // إضافة معاملة جديدة
  addTransaction(transaction: Omit<Transaction, 'id' | 'timestamp'>): Transaction {
    const newTransaction: Transaction = {
      ...transaction,
      id: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
    };

    if (!this.transactions.has(transaction.userId)) {
      this.transactions.set(transaction.userId, []);
    }

    this.transactions.get(transaction.userId)!.push(newTransaction);

    // تحديث رصيد الحساب
    this.updateAccountBalance(transaction.userId, transaction.amount, transaction.type);

    return newTransaction;
  }

  // إنشاء حساب جديد
  createAccount(account: Omit<Account, 'id' | 'createdAt'>): Account {
    const newAccount: Account = {
      ...account,
      id: `acc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
    };

    if (!this.accounts.has(account.userId)) {
      this.accounts.set(account.userId, []);
    }

    this.accounts.get(account.userId)!.push(newAccount);
    return newAccount;
  }

  // الحصول على الحسابات
  getAccounts(userId: number): Account[] {
    return this.accounts.get(userId) || [];
  }

  // الحصول على المعاملات
  getTransactions(userId: number, limit: number = 50): Transaction[] {
    const userTransactions = this.transactions.get(userId) || [];
    return userTransactions.slice(-limit).reverse();
  }

  // تحديث رصيد الحساب
  private updateAccountBalance(userId: number, amount: number, type: string): void {
    const accounts = this.accounts.get(userId) || [];
    if (accounts.length > 0) {
      const mainAccount = accounts[0];
      if (type === 'income') {
        mainAccount.balance += amount;
      } else if (type === 'expense') {
        mainAccount.balance -= amount;
      }
    }
  }

  // إنشاء تقرير مالي
  generateReport(userId: number, period: 'daily' | 'weekly' | 'monthly' | 'yearly'): FinancialReport {
    const transactions = this.transactions.get(userId) || [];
    const now = new Date();
    let startDate = new Date();

    switch (period) {
      case 'daily':
        startDate.setDate(now.getDate() - 1);
        break;
      case 'weekly':
        startDate.setDate(now.getDate() - 7);
        break;
      case 'monthly':
        startDate.setMonth(now.getMonth() - 1);
        break;
      case 'yearly':
        startDate.setFullYear(now.getFullYear() - 1);
        break;
    }

    const periodTransactions = transactions.filter(t => t.timestamp > startDate);

    const totalIncome = periodTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalExpense = periodTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      userId,
      period,
      totalIncome,
      totalExpense,
      netProfit: totalIncome - totalExpense,
      transactions: periodTransactions,
      generatedAt: new Date(),
    };
  }

  // حساب الإحصائيات
  getStatistics(userId: number): {
    totalBalance: number;
    totalTransactions: number;
    averageTransaction: number;
    topCategories: Array<{ category: string; amount: number }>;
  } {
    const accounts = this.accounts.get(userId) || [];
    const transactions = this.transactions.get(userId) || [];

    const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

    const categoryMap: Record<string, number> = {};
    transactions.forEach(t => {
      categoryMap[t.category] = (categoryMap[t.category] || 0) + t.amount;
    });

    const topCategories = Object.entries(categoryMap)
      .map(([category, amount]) => ({ category, amount }))
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 5);

    return {
      totalBalance,
      totalTransactions: transactions.length,
      averageTransaction:
        transactions.length > 0
          ? transactions.reduce((sum, t) => sum + t.amount, 0) / transactions.length
          : 0,
      topCategories,
    };
  }

  // تصدير البيانات المالية
  exportFinancialData(userId: number): { accounts: Account[]; transactions: Transaction[] } {
    return {
      accounts: this.accounts.get(userId) || [],
      transactions: this.transactions.get(userId) || [],
    };
  }
}

export const financialSystem = new FinancialSystem();

// Dummy data للاختبار
export function initializeDummyFinancialData(userId: number): void {
  // إنشاء حسابات
  financialSystem.createAccount({
    userId,
    name: 'الحساب الرئيسي',
    balance: 50000,
    currency: 'EGP',
    type: 'business',
  });

  financialSystem.createAccount({
    userId,
    name: 'حساب المراكز الطبية',
    balance: 150000,
    currency: 'EGP',
    type: 'business',
  });

  // إضافة معاملات تجريبية
  const categories = ['راتب', 'مبيعات', 'مصاريف', 'استثمار', 'تحويل'];

  for (let i = 0; i < 20; i++) {
    const isIncome = Math.random() > 0.4;
    financialSystem.addTransaction({
      userId,
      type: isIncome ? 'income' : 'expense',
      amount: Math.floor(Math.random() * 10000) + 1000,
      currency: 'EGP',
      description: `معاملة تجريبية #${i + 1}`,
      status: 'completed',
      category: categories[Math.floor(Math.random() * categories.length)],
      paymentMethod: Math.random() > 0.5 ? 'vodafone_cash' : 'bank_transfer',
    });
  }
}
