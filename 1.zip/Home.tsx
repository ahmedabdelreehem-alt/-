import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import InteractiveAvatar from '@/components/InteractiveAvatar';
import HybridChatSystem from '@/components/HybridChatSystem';
import AdminDashboard from '@/components/AdminDashboard';
import { Button } from '@/components/ui/button';
import { getLoginUrl } from '@/const';

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'avatar' | 'chat' | 'admin'>('avatar');
  const [isListening, setIsListening] = useState(false);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center px-4">
        <div className="max-w-md w-full text-center">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-violet-400 bg-clip-text text-transparent mb-4">
            Smart Assistant
          </h1>
          <p className="text-slate-300 mb-8">
            Your personal AI companion for intelligent task management and automation
          </p>
          <a href={getLoginUrl()}>
            <Button className="w-full bg-gradient-to-r from-purple-600 to-violet-600 hover:shadow-lg hover:shadow-purple-500/50 text-white py-6 text-lg">
              Sign In with Manus
            </Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="border-b border-purple-500/20 bg-gradient-to-r from-slate-900 to-slate-950 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-violet-400 bg-clip-text text-transparent">
              Smart Assistant
            </h1>
            <p className="text-sm text-slate-400">Welcome, {user?.name || 'User'}</p>
          </div>
          <button
            onClick={() => logout()}
            className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors duration-300"
          >
            Logout
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-4 mb-8 flex-wrap">
          <button
            onClick={() => setActiveTab('avatar')}
            className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 ${
              activeTab === 'avatar'
                ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-lg shadow-purple-500/50'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            Avatar Interface
          </button>
          <button
            onClick={() => setActiveTab('chat')}
            className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 ${
              activeTab === 'chat'
                ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-lg shadow-purple-500/50'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            Chat Interface
          </button>
          {user?.role === 'admin' && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 ${
                activeTab === 'admin'
                  ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-lg shadow-purple-500/50'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Admin Panel
            </button>
          )}
        </div>

        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl border border-purple-500/20 p-8">
          {activeTab === 'avatar' && (
            <InteractiveAvatar isListening={isListening} />
          )}
          {activeTab === 'chat' && (
            <HybridChatSystem />
          )}
          {activeTab === 'admin' && user?.role === 'admin' && (
            <AdminDashboard />
          )}
        </div>
      </div>
    </div>
  );
}
