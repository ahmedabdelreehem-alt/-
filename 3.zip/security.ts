import crypto from 'crypto';
import { createHmac } from 'crypto';

/**
 * Security utilities for the application
 * Includes encryption, hashing, token generation, and validation
 */

// ============ ENCRYPTION & DECRYPTION ============

const ENCRYPTION_ALGORITHM = 'aes-256-gcm';
const ENCRYPTION_KEY = process.env.JWT_SECRET || 'default-secret-key-change-in-production';

export function encryptData(data: string, key: string = ENCRYPTION_KEY): string {
  try {
    // Generate a random IV (Initialization Vector)
    const iv = crypto.randomBytes(16);
    
    // Create cipher
    const cipher = crypto.createCipheriv(
      ENCRYPTION_ALGORITHM,
      Buffer.from(key.padEnd(32, '0').slice(0, 32)),
      iv
    );
    
    // Encrypt data
    let encrypted = cipher.update(data, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    // Get auth tag
    const authTag = cipher.getAuthTag();
    
    // Combine IV + authTag + encrypted data
    const result = iv.toString('hex') + ':' + authTag.toString('hex') + ':' + encrypted;
    
    return result;
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
}

export function decryptData(encryptedData: string, key: string = ENCRYPTION_KEY): string {
  try {
    const parts = encryptedData.split(':');
    if (parts.length !== 3) {
      throw new Error('Invalid encrypted data format');
    }
    
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    
    const decipher = crypto.createDecipheriv(
      ENCRYPTION_ALGORITHM,
      Buffer.from(key.padEnd(32, '0').slice(0, 32)),
      iv
    );
    
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data');
  }
}

// ============ HASHING ============

export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

export function hashSHA256(data: string): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

// ============ TOKEN GENERATION ============

export function generateToken(length: number = 32): string {
  return crypto.randomBytes(length).toString('hex');
}

export function generateSessionToken(): string {
  return generateToken(64);
}

export function generateApiKey(): string {
  return 'sk_' + generateToken(32);
}

// ============ HMAC SIGNING ============

export function signData(data: string, secret: string): string {
  return createHmac('sha256', secret).update(data).digest('hex');
}

export function verifySignature(data: string, signature: string, secret: string): boolean {
  const expectedSignature = signData(data, secret);
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

// ============ INPUT VALIDATION & SANITIZATION ============

export function sanitizeInput(input: string): string {
  return input
    .trim()
    .replace(/[<>\"']/g, '')
    .slice(0, 1000); // Limit length
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 320;
}

export function validateUsername(username: string): boolean {
  const usernameRegex = /^[a-zA-Z0-9_-]{3,20}$/;
  return usernameRegex.test(username);
}

export function validatePassword(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('كلمة المرور يجب أن تحتوي على حرف كبير');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('كلمة المرور يجب أن تحتوي على حرف صغير');
  }
  if (!/[0-9]/.test(password)) {
    errors.push('كلمة المرور يجب أن تحتوي على رقم');
  }
  if (!/[!@#$%^&*]/.test(password)) {
    errors.push('كلمة المرور يجب أن تحتوي على رمز خاص');
  }
  
  return {
    valid: errors.length === 0,
    errors,
  };
}

// ============ RATE LIMITING ============

const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

export function checkRateLimit(key: string, maxRequests: number = 100, windowMs: number = 60000): boolean {
  const now = Date.now();
  const record = rateLimitStore.get(key);
  
  if (!record || now > record.resetTime) {
    rateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
    return true;
  }
  
  if (record.count < maxRequests) {
    record.count++;
    return true;
  }
  
  return false;
}

export function getRateLimitInfo(key: string): { remaining: number; resetTime: number } | null {
  const record = rateLimitStore.get(key);
  if (!record) return null;
  
  return {
    remaining: Math.max(0, 100 - record.count),
    resetTime: record.resetTime,
  };
}

// ============ CSRF PROTECTION ============

const csrfTokenStore = new Map<string, { token: string; createdAt: number }>();

export function generateCSRFToken(sessionId: string): string {
  const token = generateToken(32);
  csrfTokenStore.set(sessionId, { token, createdAt: Date.now() });
  return token;
}

export function verifyCSRFToken(sessionId: string, token: string): boolean {
  const record = csrfTokenStore.get(sessionId);
  
  if (!record) return false;
  
  // Token valid for 24 hours
  if (Date.now() - record.createdAt > 24 * 60 * 60 * 1000) {
    csrfTokenStore.delete(sessionId);
    return false;
  }
  
  return crypto.timingSafeEqual(
    Buffer.from(record.token),
    Buffer.from(token)
  );
}

// ============ XSS PROTECTION ============

export function escapeHtml(text: string): string {
  const map: Record<string, string> = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;',
  };
  return text.replace(/[&<>"']/g, (char) => map[char]);
}

// ============ SQL INJECTION PREVENTION ============

export function validateSQLInput(input: string): boolean {
  // Check for common SQL injection patterns
  const sqlPatterns = [
    /(\b(UNION|SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)/i,
    /(-{2}|\/\*|\*\/|;)/,
    /('|")(.*?)(OR|AND)(.*?)('|")/i,
  ];
  
  return !sqlPatterns.some(pattern => pattern.test(input));
}

// ============ SECURITY HEADERS ============

export function getSecurityHeaders(): Record<string, string> {
  return {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'",
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
  };
}

// ============ AUDIT LOGGING ============

export interface AuditLog {
  timestamp: Date;
  userId?: number;
  action: string;
  resource: string;
  status: 'success' | 'failure';
  details?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
}

const auditLogs: AuditLog[] = [];

export function logAudit(log: AuditLog): void {
  auditLogs.push({
    ...log,
    timestamp: new Date(),
  });
  
  // Keep only last 10000 logs in memory
  if (auditLogs.length > 10000) {
    auditLogs.shift();
  }
}

export function getAuditLogs(filter?: { userId?: number; action?: string; status?: 'success' | 'failure' }): AuditLog[] {
  if (!filter) return auditLogs;
  
  return auditLogs.filter(log => {
    if (filter.userId && log.userId !== filter.userId) return false;
    if (filter.action && log.action !== filter.action) return false;
    if (filter.status && log.status !== filter.status) return false;
    return true;
  });
}

// ============ PERMISSION CHECKING ============

export const PERMISSIONS = {
  CHAT: {
    CREATE: 'chat:create',
    READ: 'chat:read',
    UPDATE: 'chat:update',
    DELETE: 'chat:delete',
  },
  ADMIN: {
    MANAGE_USERS: 'admin:manage_users',
    MANAGE_SETTINGS: 'admin:manage_settings',
    VIEW_LOGS: 'admin:view_logs',
    MANAGE_PERMISSIONS: 'admin:manage_permissions',
  },
  AVATAR: {
    CUSTOMIZE: 'avatar:customize',
    USE: 'avatar:use',
  },
};

export function requirePermission(userPermissions: string[], requiredPermission: string): boolean {
  return userPermissions.includes(requiredPermission) || userPermissions.includes('*');
}

export function requireAnyPermission(userPermissions: string[], requiredPermissions: string[]): boolean {
  return requiredPermissions.some(perm => userPermissions.includes(perm)) || userPermissions.includes('*');
}

export function requireAllPermissions(userPermissions: string[], requiredPermissions: string[]): boolean {
  return requiredPermissions.every(perm => userPermissions.includes(perm)) || userPermissions.includes('*');
}
