import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Users, MessageSquare, BarChart3, LogOut } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);

  // Check if user is admin
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-950">
        <Card className="p-8 bg-slate-800 border-red-500/30 max-w-md">
          <h1 className="text-2xl font-bold text-red-400 mb-4">🚫 غير مصرح</h1>
          <p className="text-slate-300 mb-6">
            أنت لا تملك صلاحيات كافية للوصول إلى لوحة التحكم الإدارية.
          </p>
          <Button
            onClick={() => setLocation("/")}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            العودة للرئيسية
          </Button>
        </Card>
      </div>
    );
  }

  // Get admin stats
  const { data: stats, isLoading: isLoadingStats } = trpc.admin.getStats.useQuery();

  // Get users list
  const { data: users, isLoading: isLoadingUsers } = trpc.admin.getUsers.useQuery({
    limit: 100,
    offset: 0,
  });

  // Update user role mutation
  const updateUserRoleMutation = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث صلاحية المستخدم");
      trpc.useUtils().admin.getUsers.invalidate();
    },
    onError: () => {
      toast.error("فشل تحديث صلاحية المستخدم");
    },
  });

  const handlePromoteUser = (userId: number) => {
    updateUserRoleMutation.mutate({
      userId,
      role: "admin",
    });
  };

  const handleDemoteUser = (userId: number) => {
    updateUserRoleMutation.mutate({
      userId,
      role: "user",
    });
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-950">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">لوحة التحكم الإدارية</h1>
            <p className="text-slate-400">مرحباً {user?.name} (مسؤول)</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-red-500/30 text-red-400 hover:bg-red-500/10"
          >
            <LogOut className="w-4 h-4 mr-2" />
            تسجيل الخروج
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-purple-500/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-2">إجمالي المستخدمين</p>
                <p className="text-3xl font-bold text-white">
                  {isLoadingStats ? <Loader2 className="w-6 h-6 animate-spin" /> : stats?.totalUsers || 0}
                </p>
              </div>
              <Users className="w-8 h-8 text-purple-500 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-blue-500/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-2">المحادثات</p>
                <p className="text-3xl font-bold text-white">
                  {isLoadingStats ? <Loader2 className="w-6 h-6 animate-spin" /> : stats?.totalConversations || 0}
                </p>
              </div>
              <MessageSquare className="w-8 h-8 text-blue-500 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-green-500/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-2">الرسائل</p>
                <p className="text-3xl font-bold text-white">
                  {isLoadingStats ? <Loader2 className="w-6 h-6 animate-spin" /> : stats?.totalMessages || 0}
                </p>
              </div>
              <BarChart3 className="w-8 h-8 text-green-500 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-yellow-500/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-2">المستخدمون النشطون</p>
                <p className="text-3xl font-bold text-white">
                  {isLoadingStats ? <Loader2 className="w-6 h-6 animate-spin" /> : stats?.activeUsers || 0}
                </p>
              </div>
              <Users className="w-8 h-8 text-yellow-500 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Users Management */}
        <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-purple-500/30 p-6">
          <h2 className="text-2xl font-bold text-white mb-6">إدارة المستخدمين</h2>

          {isLoadingUsers ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            </div>
          ) : users && users.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-3 px-4 text-slate-300">الاسم</th>
                    <th className="text-left py-3 px-4 text-slate-300">البريد الإلكتروني</th>
                    <th className="text-left py-3 px-4 text-slate-300">الصلاحية</th>
                    <th className="text-left py-3 px-4 text-slate-300">آخر دخول</th>
                    <th className="text-left py-3 px-4 text-slate-300">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u: any) => (
                    <tr key={u.id} className="border-b border-slate-700 hover:bg-slate-700/30 transition">
                      <td className="py-3 px-4 text-white">{u.name}</td>
                      <td className="py-3 px-4 text-slate-300">{u.email}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            u.role === "admin"
                              ? "bg-purple-500/20 text-purple-400"
                              : "bg-slate-500/20 text-slate-400"
                          }`}
                        >
                          {u.role === "admin" ? "مسؤول" : "مستخدم"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400">
                        {new Date(u.lastSignedIn).toLocaleDateString("ar-SA")}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          {u.role === "user" ? (
                            <Button
                              onClick={() => handlePromoteUser(u.id)}
                              disabled={updateUserRoleMutation.isPending}
                              size="sm"
                              className="bg-purple-600 hover:bg-purple-700 text-xs"
                            >
                              {updateUserRoleMutation.isPending ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                "ترقية"
                              )}
                            </Button>
                          ) : (
                            <Button
                              onClick={() => handleDemoteUser(u.id)}
                              disabled={updateUserRoleMutation.isPending}
                              size="sm"
                              variant="outline"
                              className="border-slate-600 text-xs"
                            >
                              {updateUserRoleMutation.isPending ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                "إلغاء ترقية"
                              )}
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-slate-400 text-center py-12">لا توجد مستخدمون</p>
          )}
        </Card>
      </div>
    </div>
  );
}
