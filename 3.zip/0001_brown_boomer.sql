CREATE TABLE `avatarSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`avatarName` varchar(255) NOT NULL DEFAULT 'الرايق',
	`avatarPersonality` text,
	`voicePreference` varchar(255) DEFAULT 'ar-SA',
	`voiceSpeed` int DEFAULT 1,
	`visualizationStyle` varchar(255) DEFAULT 'wave',
	`colorScheme` json,
	`isEnabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `avatarSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `avatarSettings_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255),
	`description` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`level` enum('debug','info','warn','error','critical') NOT NULL DEFAULT 'info',
	`action` varchar(255) NOT NULL,
	`message` text,
	`metadata` json,
	`ipAddress` varchar(45),
	`userAgent` varchar(512),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `memory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`conversationId` int,
	`memoryType` enum('short_term','long_term','user_preference','context') NOT NULL,
	`content` longtext NOT NULL,
	`importance` int DEFAULT 1,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `memory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('user','assistant','system') NOT NULL,
	`content` longtext NOT NULL,
	`contentType` enum('text','audio','image','mixed') NOT NULL DEFAULT 'text',
	`audioUrl` varchar(512),
	`imageUrl` varchar(512),
	`tokens` int,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `permissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`resource` varchar(255) NOT NULL,
	`action` varchar(255) NOT NULL,
	`granted` boolean NOT NULL DEFAULT true,
	`grantedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `permissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sessionToken` varchar(512) NOT NULL,
	`ipAddress` varchar(45),
	`userAgent` varchar(512),
	`isActive` boolean NOT NULL DEFAULT true,
	`lastActivity` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `sessions_sessionToken_unique` UNIQUE(`sessionToken`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`settingKey` varchar(255) NOT NULL,
	`settingValue` text,
	`isPublic` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `avatarSettings_userId_idx` ON `avatarSettings` (`userId`);--> statement-breakpoint
CREATE INDEX `conversations_userId_idx` ON `conversations` (`userId`);--> statement-breakpoint
CREATE INDEX `logs_userId_idx` ON `logs` (`userId`);--> statement-breakpoint
CREATE INDEX `logs_level_idx` ON `logs` (`level`);--> statement-breakpoint
CREATE INDEX `logs_createdAt_idx` ON `logs` (`createdAt`);--> statement-breakpoint
CREATE INDEX `memory_userId_idx` ON `memory` (`userId`);--> statement-breakpoint
CREATE INDEX `memory_conversationId_idx` ON `memory` (`conversationId`);--> statement-breakpoint
CREATE INDEX `memory_memoryType_idx` ON `memory` (`memoryType`);--> statement-breakpoint
CREATE INDEX `messages_conversationId_idx` ON `messages` (`conversationId`);--> statement-breakpoint
CREATE INDEX `messages_userId_idx` ON `messages` (`userId`);--> statement-breakpoint
CREATE INDEX `permissions_userId_idx` ON `permissions` (`userId`);--> statement-breakpoint
CREATE INDEX `permissions_resource_idx` ON `permissions` (`resource`);--> statement-breakpoint
CREATE INDEX `sessions_userId_idx` ON `sessions` (`userId`);--> statement-breakpoint
CREATE INDEX `sessions_sessionToken_idx` ON `sessions` (`sessionToken`);--> statement-breakpoint
CREATE INDEX `settings_userId_idx` ON `settings` (`userId`);--> statement-breakpoint
CREATE INDEX `settings_settingKey_idx` ON `settings` (`settingKey`);