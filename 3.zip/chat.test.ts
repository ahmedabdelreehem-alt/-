import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { appRouter } from './routers';
import { createConversation, createMessage, getMessagesByConversationId, getConversationsByUserId } from './db';

// Mock user context
const mockUser = {
  id: 1,
  openId: 'test-user-123',
  email: 'test@example.com',
  name: 'Test User',
  loginMethod: 'test',
  role: 'user' as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

const mockContext = {
  user: mockUser,
  req: { protocol: 'https', headers: {} } as any,
  res: { clearCookie: () => {} } as any,
};

describe('Chat System', () => {
  let conversationId: number;

  beforeAll(async () => {
    // Create a test conversation
    const result = await createConversation(mockUser.id, 'Test Conversation');
    conversationId = (result as any).insertId || 1;
  });

  it('should create a new conversation', async () => {
    const result = await createConversation(mockUser.id, 'New Test Conversation');
    expect(result).toBeDefined();
    console.log('✅ Conversation created successfully');
  });

  it('should get conversations for a user', async () => {
    const conversations = await getConversationsByUserId(mockUser.id, 10);
    expect(Array.isArray(conversations)).toBe(true);
    console.log(`✅ Retrieved ${conversations.length} conversations`);
  });

  it('should create a message in a conversation', async () => {
    const result = await createMessage(
      conversationId,
      mockUser.id,
      'user',
      'Hello, how are you?'
    );
    expect(result).toBeDefined();
    console.log('✅ User message created successfully');
  });

  it('should create an assistant response', async () => {
    const result = await createMessage(
      conversationId,
      mockUser.id,
      'assistant',
      'I am doing well, thank you for asking!'
    );
    expect(result).toBeDefined();
    console.log('✅ Assistant message created successfully');
  });

  it('should retrieve messages from a conversation', async () => {
    const messages = await getMessagesByConversationId(conversationId, 100);
    expect(Array.isArray(messages)).toBe(true);
    expect(messages.length).toBeGreaterThanOrEqual(2);
    console.log(`✅ Retrieved ${messages.length} messages`);
  });

  it('should handle Arabic text in messages', async () => {
    const arabicMessage = 'السلام عليكم، كيف حالك؟';
    const result = await createMessage(
      conversationId,
      mockUser.id,
      'user',
      arabicMessage
    );
    expect(result).toBeDefined();

    const messages = await getMessagesByConversationId(conversationId, 100);
    const foundMessage = messages.find(m => m.content === arabicMessage);
    expect(foundMessage).toBeDefined();
    expect(foundMessage?.content).toBe(arabicMessage);
    console.log('✅ Arabic text handled correctly');
  });

  it('should handle long messages', async () => {
    const longMessage = 'A'.repeat(1000);
    const result = await createMessage(
      conversationId,
      mockUser.id,
      'user',
      longMessage
    );
    expect(result).toBeDefined();
    console.log('✅ Long message handled correctly');
  });

  it('should maintain message order', async () => {
    const messages = await getMessagesByConversationId(conversationId, 100);
    
    // Check that messages are in chronological order
    for (let i = 1; i < messages.length; i++) {
      const prevTime = new Date(messages[i - 1].createdAt).getTime();
      const currTime = new Date(messages[i].createdAt).getTime();
      expect(currTime).toBeGreaterThanOrEqual(prevTime);
    }
    console.log('✅ Messages are in correct chronological order');
  });
});

describe('Chat tRPC Procedures', () => {
  it('should handle protected procedures', async () => {
    const caller = appRouter.createCaller(mockContext);
    
    // Test that we can call protected procedures
    const result = await caller.chat.getConversations({ limit: 10, offset: 0 });
    expect(Array.isArray(result)).toBe(true);
    console.log('✅ Protected procedure works correctly');
  });

  it('should handle chat message sending', async () => {
    const caller = appRouter.createCaller(mockContext);
    
    // Create a conversation first
    await caller.chat.createConversation({});
    
    // Get conversations
    const conversations = await caller.chat.getConversations({ limit: 10 });
    expect(conversations.length).toBeGreaterThan(0);
    console.log('✅ Chat message sending works correctly');
  });
});
