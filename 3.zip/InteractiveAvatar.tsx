import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Volume2, Settings } from 'lucide-react';

interface AudioVisualizerProps {
  isListening: boolean;
}

export const InteractiveAvatar: React.FC<AudioVisualizerProps> = ({ isListening }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const dataArrayRef = useRef<any>(null);
  const animationIdRef = useRef<number | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(70);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const initAudioContext = async () => {
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        audioContextRef.current = audioContext;

        const analyser = audioContext.createAnalyser();
        analyser.fftSize = 256;
        analyserRef.current = analyser;

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        dataArrayRef.current = dataArray;

        if (isListening) {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const source = audioContext.createMediaStreamSource(stream);
          source.connect(analyser);
        }
      } catch (error) {
        console.error('Audio context error:', error);
      }
    };

    const drawAvatar = () => {
      if (!ctx || !analyserRef.current || !dataArrayRef.current) return;

      const width = canvas.width;
      const height = canvas.height;

      analyserRef.current.getByteFrequencyData(dataArrayRef.current);

      ctx.fillStyle = 'rgba(15, 23, 42, 0.1)';
      ctx.fillRect(0, 0, width, height);

      const centerX = width / 2;
      const centerY = height / 2;
      const baseRadius = 60;

      ctx.save();
      ctx.translate(centerX, centerY);

      const average = dataArrayRef.current.reduce((a: number, b: number) => a + b) / dataArrayRef.current.length;
      const scale = 1 + average / 256 * 0.3;

      ctx.fillStyle = `rgba(168, 85, 247, ${0.3 + average / 256 * 0.4})`;
      ctx.beginPath();
      ctx.arc(0, 0, baseRadius * scale, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = `rgba(168, 85, 247, ${0.6 + average / 256 * 0.4})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, baseRadius * scale, 0, Math.PI * 2);
      ctx.stroke();

      for (let i = 0; i < dataArrayRef.current.length; i++) {
        const value = dataArrayRef.current[i];
        const angle = (i / dataArrayRef.current.length) * Math.PI * 2;
        const radius = baseRadius + (value / 256) * 40;

        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;

        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }

      ctx.strokeStyle = `rgba(139, 92, 246, ${0.7 + average / 256 * 0.3})`;
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.beginPath();
      ctx.arc(-15, -10, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(15, -10, 8, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.beginPath();
      ctx.arc(-15, -10, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(15, -10, 4, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      if (isListening) {
        animationIdRef.current = requestAnimationFrame(drawAvatar);
      }
    };

    initAudioContext();
    if (isListening) {
      drawAvatar();
    } else {
      const width = canvas.width;
      const height = canvas.height;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.1)';
      ctx.fillRect(0, 0, width, height);
      const centerX = width / 2;
      const centerY = height / 2;
      ctx.fillStyle = 'rgba(168, 85, 247, 0.3)';
      ctx.beginPath();
      ctx.arc(centerX, centerY, 60, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(168, 85, 247, 0.6)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
    };
  }, [isListening]);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl border border-purple-500/30 p-8">
        <h2 className="text-center text-2xl font-bold text-purple-400 mb-6">Interactive Avatar</h2>

        <div className="flex justify-center mb-8">
          <canvas
            ref={canvasRef}
            width={400}
            height={400}
            className="rounded-xl border border-purple-500/50 bg-gradient-to-br from-slate-900 to-slate-950"
          />
        </div>

        <div className="flex justify-center gap-4 mb-6">
          <button className={`p-3 rounded-full transition-all ${isListening ? 'bg-red-500 hover:bg-red-600' : 'bg-purple-600 hover:bg-purple-700'}`}>
            {isListening ? <MicOff className="w-6 h-6 text-white" /> : <Mic className="w-6 h-6 text-white" />}
          </button>
          <button className="p-3 rounded-full bg-slate-700 hover:bg-slate-600 transition-all">
            <Volume2 className="w-6 h-6 text-white" />
          </button>
          <button className="p-3 rounded-full bg-slate-700 hover:bg-slate-600 transition-all">
            <Settings className="w-6 h-6 text-white" />
          </button>
        </div>

        <div className="flex items-center gap-4">
          <span className="text-sm text-slate-400">Volume:</span>
          <input
            type="range"
            min="0"
            max="100"
            value={volume}
            onChange={(e) => setVolume(Number(e.target.value))}
            className="flex-1 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
          />
          <span className="text-sm text-slate-400">{volume}%</span>
        </div>

        <div className="mt-6 p-4 bg-purple-900/30 rounded-lg border border-purple-500/30">
          <p className="text-center text-sm text-slate-300">
            {isListening ? 'Listening...' : 'Click the microphone to start'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default InteractiveAvatar;
