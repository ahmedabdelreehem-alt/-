# دليل النشر - الرايق أفاتار مصر

## نظرة عامة

هذا المشروع يمكن نشره على:
1. **الويب** - عبر Manus Platform
2. **Android** - تطبيق APK
3. **iOS** - تطبيق IPA (عند الحاجة)

---

## النشر على الويب (Manus Platform)

### المتطلبات
- حساب Manus
- تطبيق مُسجل على Manus

### الخطوات

#### 1. إعداد البيئة
```bash
# تثبيت المتطلبات
pnpm install

# بناء التطبيق
pnpm build
```

#### 2. النشر عبر Manus UI
1. اذهب إلى لوحة تحكم Manus
2. اختر المشروع "al-raiq-avatar-egypt"
3. اضغط على زر "Publish"
4. انتظر انتهاء النشر

#### 3. التحقق
```
URL: https://raiqavatar-hw3rhvzb.manus.space
```

---

## النشر على Google Play Store

### المتطلبات
- حساب Google Play Developer ($25 لمرة واحدة)
- APK موقع (Release APK)
- صور وأيقونات التطبيق
- وصف التطبيق

### الخطوات

#### 1. بناء Release APK
```bash
# بناء الملفات الثابتة
pnpm build

# مزامنة مع Capacitor
npx cap sync android

# بناء Release APK
cd android
./gradlew assembleRelease
```

#### 2. توقيع APK
```bash
# إنشاء مفتاح توقيع (مرة واحدة فقط)
keytool -genkey -v -keystore raiq-release-key.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias raiq-key

# توقيع APK
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
  -keystore raiq-release-key.keystore \
  app/build/outputs/apk/release/app-release-unsigned.apk raiq-key

# تحسين APK
zipalign -v 4 \
  app/build/outputs/apk/release/app-release-unsigned.apk \
  app/build/outputs/apk/release/app-release.apk
```

#### 3. إنشاء حساب Google Play Developer
1. اذهب إلى https://play.google.com/console
2. أنشئ حساباً جديداً
3. ادفع رسم التسجيل ($25)

#### 4. إنشاء تطبيق جديد
1. اضغط على "Create app"
2. أدخل اسم التطبيق: "الرايق أفاتار"
3. اختر الفئة: "Productivity"
4. اختر المحتوى: "لا يحتوي على محتوى حساس"

#### 5. تحميل APK
1. اذهب إلى "Testing" → "Internal testing"
2. اضغط على "Create new release"
3. حمّل ملف APK
4. أضف ملاحظات الإصدار

#### 6. إضافة معلومات التطبيق
1. **الأيقونة:** 512x512 PNG
2. **الصور:** 4-8 صور (1080x1920)
3. **الوصف:** وصف قصير وطويل
4. **الفئة:** Productivity
5. **التصنيف:** 3+

#### 7. إضافة سياسة الخصوصية
1. اذهب إلى "App content"
2. أضف رابط سياسة الخصوصية

#### 8. النشر
1. اذهب إلى "Release" → "Production"
2. اضغط على "Create new release"
3. حمّل APK الموقع
4. اضغط على "Review release"
5. اضغط على "Rollout to production"

---

## النشر على Firebase App Distribution

### المتطلبات
- حساب Firebase
- Firebase CLI

### الخطوات

#### 1. إعداد Firebase
```bash
# تثبيت Firebase CLI
npm install -g firebase-tools

# تسجيل الدخول
firebase login

# إنشاء مشروع Firebase
firebase init
```

#### 2. توزيع APK
```bash
# بناء Release APK
pnpm build
npx cap sync android
cd android
./gradlew assembleRelease

# توزيع عبر Firebase
firebase appdistribution:distribute \
  app/build/outputs/apk/release/app-release.apk \
  --app 1:123456789:android:abcdef123456
```

---

## النشر على GitHub Releases

### الخطوات

```bash
# إنشاء إصدار جديد
git tag v1.0.0
git push origin v1.0.0

# تحميل APK يدوياً
# 1. اذهب إلى GitHub Releases
# 2. اضغط على "Create new release"
# 3. حمّل ملف APK
```

---

## المراقبة والتحديثات

### مراقبة الأداء
- استخدم Firebase Analytics
- راقب أخطاء التطبيق
- تتبع استخدام المستخدمين

### إصدار تحديثات
```bash
# تحديث الكود
git add .
git commit -m "v1.0.1 - Bug fixes"

# بناء وتوزيع
pnpm build
npx cap sync android
cd android
./gradlew assembleRelease

# نشر على Google Play
# 1. اذهب إلى Google Play Console
# 2. اضغط على "Create new release"
# 3. حمّل APK الجديد
```

---

## متغيرات البيئة للإنتاج

```bash
# قاعدة البيانات
DATABASE_URL=mysql://prod-user:strong-password@prod-host:3306/raiq_avatar

# المصادقة
JWT_SECRET=very-long-random-secret-key

# Manus OAuth
VITE_APP_ID=production-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://auth.manus.im

# Gemini API
GEMINI_API_KEY=production-gemini-key

# Manus APIs
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=production-forge-key
VITE_FRONTEND_FORGE_API_KEY=production-frontend-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im

# التطبيق
NODE_ENV=production
```

---

## قائمة التحقق قبل النشر

- [ ] جميع الاختبارات تمرت
- [ ] لا توجد أخطاء TypeScript
- [ ] تم تحديث رقم الإصدار
- [ ] تم تحديث ملف CHANGELOG
- [ ] تم اختبار على جهاز فعلي
- [ ] تم فحص الأداء
- [ ] تم فحص الأمان
- [ ] تم تحديث سياسة الخصوصية
- [ ] تم إضافة ملاحظات الإصدار

---

## استكشاف الأخطاء

### خطأ: "Build failed"
```bash
cd android
./gradlew clean
./gradlew assembleRelease
```

### خطأ: "Signing failed"
```bash
# تحقق من مفتاح التوقيع
keytool -list -v -keystore raiq-release-key.keystore
```

### خطأ: "Upload failed"
- تحقق من اتصال الإنترنت
- تحقق من صحة بيانات Google Play
- حاول مرة أخرى

---

## الدعم

للمساعدة والدعم:
- البريد الإلكتروني: support@raiqavatar.com
- الموقع: https://raiqavatar-hw3rhvzb.manus.space

---

## الترخيص

جميع الحقوق محفوظة © 2026 الرايق أفاتار مصر
