import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { invokeLLM, type InvokeResult } from "./_core/llm";
import { eq, sql } from "drizzle-orm";
import { users, conversations, messages } from "../drizzle/schema";
import { getDb } from "./db";
import {
  createConversation,
  getConversationsByUserId,
  createMessage,
  getMessagesByConversationId,
  createLog,
  getAvatarSettings,
  createOrUpdateAvatarSettings,
  storeMemory,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    createConversation: protectedProcedure
      .input(z.object({ title: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        try {
          await createConversation(ctx.user.id, input.title);
          await createLog("محادثة جديدة تم إنشاؤها", "info", ctx.user.id);
          return { success: true };
        } catch (error) {
          await createLog("فشل في إنشاء محادثة", "error", ctx.user.id);
          throw error;
        }
      }),

    getConversations: protectedProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ ctx, input }) => {
        try {
          return await getConversationsByUserId(ctx.user.id, input.limit, input.offset);
        } catch (error) {
          console.error("Error fetching conversations:", error);
          return [];
        }
      }),

    sendMessage: protectedProcedure
      .input(z.object({ conversationId: z.number(), message: z.string().min(1).max(5000) }))
      .mutation(async ({ ctx, input }) => {
        try {
          await createMessage(input.conversationId, ctx.user.id, "user", input.message);
          const messages = await getMessagesByConversationId(input.conversationId, 100);
          const llmMessages = messages.map(msg => ({
            role: msg.role as "user" | "assistant" | "system",
            content: msg.content,
          }));
          const systemPrompt = {
            role: "system" as const,
            content: "أنت مساعد ذكي باسم الرايق. تتحدث باللغة العربية بطريقة ودية واحترافية.",
          };
          const response = await invokeLLM({ messages: [systemPrompt, ...llmMessages] });
          const aiResponseContent = response.choices[0]?.message?.content;
          const aiResponse = typeof aiResponseContent === 'string' ? aiResponseContent : "معذرة، حدث خطأ.";
          await createMessage(input.conversationId, ctx.user.id, "assistant", aiResponse);
          await storeMemory(ctx.user.id, `المستخدم: ${input.message}\nالرد: ${aiResponse}`, "short_term");
          await createLog("رسالة تم معالجتها", "info", ctx.user.id);
          return { success: true, response: aiResponse };
        } catch (error) {
          await createLog("فشل في معالجة الرسالة", "error", ctx.user.id);
          throw error;
        }
      }),

    getMessages: protectedProcedure
      .input(z.object({ conversationId: z.number(), limit: z.number().default(100), offset: z.number().default(0) }))
      .query(async ({ ctx, input }) => {
        try {
          return await getMessagesByConversationId(input.conversationId, input.limit, input.offset);
        } catch (error) {
          console.error("Error fetching messages:", error);
          return [];
        }
      }),
  }),

  avatar: router({
    getSettings: protectedProcedure.query(async ({ ctx }) => {
      try {
        const settings = await getAvatarSettings(ctx.user.id);
        return settings || { userId: ctx.user.id, avatarName: "الرايق", voicePreference: "ar-SA" };
      } catch (error) {
        console.error("Error fetching avatar settings:", error);
        return null;
      }
    }),

    updateSettings: protectedProcedure
      .input(z.object({ avatarName: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        try {
          await createOrUpdateAvatarSettings(ctx.user.id, input.avatarName);
          await createLog("إعدادات الأفاتار تم تحديثها", "info", ctx.user.id);
          return { success: true };
        } catch (error) {
          await createLog("فشل في تحديث الإعدادات", "error", ctx.user.id);
          throw error;
        }
      }),
  }),

  admin: router({
    getStatus: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") throw new Error("غير مصرح");
      return { status: "online", timestamp: new Date(), version: "1.0.0" };
    }),

    getStats: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") throw new Error("غير مصرح");
      
      const db = await getDb();
      if (!db) throw new Error("قاعدة البيانات غير متاحة");

      const totalUsers = await db.select().from(users);
      const totalConversations = await db.select().from(conversations);
      const totalMessages = await db.select().from(messages);
      const activeUsers = await db.select().from(users).where(sql`DATEDIFF(NOW(), lastSignedIn) <= 7`);

      return {
        totalUsers: totalUsers.length,
        totalConversations: totalConversations.length,
        totalMessages: totalMessages.length,
        activeUsers: activeUsers.length,
        averageMessagesPerUser: totalUsers.length > 0 ? totalMessages.length / totalUsers.length : 0,
      };
    }),

    getUsers: protectedProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new Error("غير مصرح");
        
        const db = await getDb();
        if (!db) throw new Error("قاعدة البيانات غير متاحة");

        return await db
          .select()
          .from(users)
          .limit(input.limit)
          .offset(input.offset)
          .orderBy(sql`createdAt DESC`);
      }),

    updateUserRole: protectedProcedure
      .input(z.object({ userId: z.number(), role: z.enum(["user", "admin"]) }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new Error("غير مصرح");
        
        const db = await getDb();
        if (!db) throw new Error("قاعدة البيانات غير متاحة");

        await db
          .update(users)
          .set({ role: input.role })
          .where(eq(users.id, input.userId));

        await createLog(`تم تحديث صلاحية المستخدم ${input.userId}`, "info", ctx.user.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
