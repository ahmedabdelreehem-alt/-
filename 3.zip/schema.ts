import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, json, longtext, index } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Conversations table - stores chat sessions between users and the AI avatar
 */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }),
  description: text("description"),
  isActive: boolean("isActive").default(true).notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("conversations_userId_idx").on(table.userId),
}));

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/**
 * Messages table - stores individual messages in conversations
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: longtext("content").notNull(),
  contentType: mysqlEnum("contentType", ["text", "audio", "image", "mixed"]).default("text").notNull(),
  audioUrl: varchar("audioUrl", { length: 512 }),
  imageUrl: varchar("imageUrl", { length: 512 }),
  tokens: int("tokens"),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  conversationIdIdx: index("messages_conversationId_idx").on(table.conversationId),
  userIdIdx: index("messages_userId_idx").on(table.userId),
}));

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Logs table - stores system and user activity logs
 */
export const logs = mysqlTable("logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  level: mysqlEnum("level", ["debug", "info", "warn", "error", "critical"]).default("info").notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  message: text("message"),
  metadata: json("metadata"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  userAgent: varchar("userAgent", { length: 512 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("logs_userId_idx").on(table.userId),
  levelIdx: index("logs_level_idx").on(table.level),
  createdAtIdx: index("logs_createdAt_idx").on(table.createdAt),
}));

export type Log = typeof logs.$inferSelect;
export type InsertLog = typeof logs.$inferInsert;

/**
 * Settings table - stores user and system settings
 */
export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  settingKey: varchar("settingKey", { length: 255 }).notNull(),
  settingValue: text("settingValue"),
  isPublic: boolean("isPublic").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("settings_userId_idx").on(table.userId),
  keyIdx: index("settings_settingKey_idx").on(table.settingKey),
}));

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = typeof settings.$inferInsert;

/**
 * Permissions table - stores role-based access control (RBAC)
 */
export const permissions = mysqlTable("permissions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  resource: varchar("resource", { length: 255 }).notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  granted: boolean("granted").default(true).notNull(),
  grantedBy: int("grantedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("permissions_userId_idx").on(table.userId),
  resourceIdx: index("permissions_resource_idx").on(table.resource),
}));

export type Permission = typeof permissions.$inferSelect;
export type InsertPermission = typeof permissions.$inferInsert;

/**
 * Memory table - stores conversation context and memory for the AI
 */
export const memory = mysqlTable("memory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  conversationId: int("conversationId"),
  memoryType: mysqlEnum("memoryType", ["short_term", "long_term", "user_preference", "context"]).notNull(),
  content: longtext("content").notNull(),
  importance: int("importance").default(1),
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("memory_userId_idx").on(table.userId),
  conversationIdIdx: index("memory_conversationId_idx").on(table.conversationId),
  memoryTypeIdx: index("memory_memoryType_idx").on(table.memoryType),
}));

export type Memory = typeof memory.$inferSelect;
export type InsertMemory = typeof memory.$inferInsert;

/**
 * Avatar Settings table - stores avatar customization and preferences
 */
export const avatarSettings = mysqlTable("avatarSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  avatarName: varchar("avatarName", { length: 255 }).default("الرايق").notNull(),
  avatarPersonality: text("avatarPersonality"),
  voicePreference: varchar("voicePreference", { length: 255 }).default("ar-SA"),
  voiceSpeed: int("voiceSpeed").default(1),
  visualizationStyle: varchar("visualizationStyle", { length: 255 }).default("wave"),
  colorScheme: json("colorScheme"),
  isEnabled: boolean("isEnabled").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("avatarSettings_userId_idx").on(table.userId),
}));

export type AvatarSetting = typeof avatarSettings.$inferSelect;
export type InsertAvatarSetting = typeof avatarSettings.$inferInsert;

/**
 * Session table - stores active sessions for security
 */
export const sessions = mysqlTable("sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sessionToken: varchar("sessionToken", { length: 512 }).notNull().unique(),
  ipAddress: varchar("ipAddress", { length: 45 }),
  userAgent: varchar("userAgent", { length: 512 }),
  isActive: boolean("isActive").default(true).notNull(),
  lastActivity: timestamp("lastActivity").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("sessions_userId_idx").on(table.userId),
  tokenIdx: index("sessions_sessionToken_idx").on(table.sessionToken),
}));

export type Session = typeof sessions.$inferSelect;
export type InsertSession = typeof sessions.$inferInsert;

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  conversations: many(conversations),
  messages: many(messages),
  logs: many(logs),
  permissions: many(permissions),
  memory: many(memory),
  avatarSettings: many(avatarSettings),
  sessions: many(sessions),
}));

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  user: one(users, {
    fields: [conversations.userId],
    references: [users.id],
  }),
  messages: many(messages),
  memory: many(memory),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
  user: one(users, {
    fields: [messages.userId],
    references: [users.id],
  }),
}));

export const logsRelations = relations(logs, ({ one }) => ({
  user: one(users, {
    fields: [logs.userId],
    references: [users.id],
  }),
}));

export const permissionsRelations = relations(permissions, ({ one }) => ({
  user: one(users, {
    fields: [permissions.userId],
    references: [users.id],
  }),
  grantedByUser: one(users, {
    fields: [permissions.grantedBy],
    references: [users.id],
  }),
}));

export const memoryRelations = relations(memory, ({ one }) => ({
  user: one(users, {
    fields: [memory.userId],
    references: [users.id],
  }),
  conversation: one(conversations, {
    fields: [memory.conversationId],
    references: [conversations.id],
  }),
}));

export const avatarSettingsRelations = relations(avatarSettings, ({ one }) => ({
  user: one(users, {
    fields: [avatarSettings.userId],
    references: [users.id],
  }),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, {
    fields: [sessions.userId],
    references: [users.id],
  }),
}));

// TODO: Add your additional tables here