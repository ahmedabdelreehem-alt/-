import { describe, it, expect } from 'vitest';
import { invokeLLM } from '../_core/llm';

describe('Gemini API Integration', () => {
  it('should validate Gemini API Key by making a test request', async () => {
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'user',
            content: 'Hello, please respond with just "OK" to confirm you are working.',
          },
        ],
      });

      expect(response).toBeDefined();
      expect(response.choices).toBeDefined();
      expect(response.choices.length).toBeGreaterThan(0);
      expect(response.choices[0].message).toBeDefined();
      expect(response.choices[0].message.content).toBeDefined();
      
      console.log('✅ Gemini API Key is valid and working!');
      console.log('Response:', response.choices[0].message.content);
    } catch (error: any) {
      console.error('❌ Gemini API Error:', error.message);
      throw new Error(`Gemini API validation failed: ${error.message}`);
    }
  });

  it('should handle Arabic text properly', async () => {
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'user',
            content: 'السلام عليكم، هل تستطيع الرد بالعربية؟',
          },
        ],
      });

      expect(response).toBeDefined();
      expect(response.choices[0].message.content).toBeDefined();
      
      console.log('✅ Arabic text processing works!');
    } catch (error: any) {
      console.error('❌ Arabic processing error:', error.message);
      throw new Error(`Arabic text processing failed: ${error.message}`);
    }
  });
});
