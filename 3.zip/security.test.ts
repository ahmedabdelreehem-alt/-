import { describe, it, expect } from 'vitest';
import {
  encryptData,
  decryptData,
  hashPassword,
  verifyPassword,
  generateToken,
  validateEmail,
  validatePassword,
  sanitizeInput,
  escapeHtml,
  getSecurityHeaders,
} from './security';

describe('Security Utilities', () => {
  describe('Encryption & Decryption', () => {
    it('should encrypt and decrypt data correctly', () => {
      const originalData = 'السلام عليكم ورحمة الله وبركاته';
      const encrypted = encryptData(originalData);
      const decrypted = decryptData(encrypted);
      
      expect(decrypted).toBe(originalData);
      console.log('✅ Encryption/Decryption works correctly');
    });

    it('should produce different encrypted outputs for same input', () => {
      const data = 'test data';
      const encrypted1 = encryptData(data);
      const encrypted2 = encryptData(data);
      
      expect(encrypted1).not.toBe(encrypted2);
      expect(decryptData(encrypted1)).toBe(data);
      expect(decryptData(encrypted2)).toBe(data);
      console.log('✅ Encryption produces unique outputs');
    });
  });

  describe('Password Hashing', () => {
    it('should hash passwords consistently', () => {
      const password = 'MySecurePassword123!';
      const hash1 = hashPassword(password);
      const hash2 = hashPassword(password);
      
      expect(hash1).toBe(hash2);
      console.log('✅ Password hashing is consistent');
    });

    it('should verify correct passwords', () => {
      const password = 'MySecurePassword123!';
      const hash = hashPassword(password);
      
      expect(verifyPassword(password, hash)).toBe(true);
      console.log('✅ Password verification works correctly');
    });

    it('should reject incorrect passwords', () => {
      const password = 'MySecurePassword123!';
      const wrongPassword = 'WrongPassword123!';
      const hash = hashPassword(password);
      
      expect(verifyPassword(wrongPassword, hash)).toBe(false);
      console.log('✅ Wrong passwords are rejected');
    });
  });

  describe('Token Generation', () => {
    it('should generate random tokens', () => {
      const token1 = generateToken(32);
      const token2 = generateToken(32);
      
      expect(token1).not.toBe(token2);
      expect(token1.length).toBe(64); // 32 bytes = 64 hex chars
      console.log('✅ Token generation works correctly');
    });

    it('should generate different length tokens', () => {
      const token16 = generateToken(16);
      const token32 = generateToken(32);
      
      expect(token16.length).toBe(32); // 16 bytes = 32 hex chars
      expect(token32.length).toBe(64); // 32 bytes = 64 hex chars
      console.log('✅ Token length generation works correctly');
    });
  });

  describe('Input Validation', () => {
    it('should validate correct emails', () => {
      expect(validateEmail('test@example.com')).toBe(true);
      expect(validateEmail('user+tag@domain.co.uk')).toBe(true);
      console.log('✅ Valid emails are accepted');
    });

    it('should reject invalid emails', () => {
      expect(validateEmail('invalid')).toBe(false);
      expect(validateEmail('test@')).toBe(false);
      expect(validateEmail('@example.com')).toBe(false);
      console.log('✅ Invalid emails are rejected');
    });

    it('should validate strong passwords', () => {
      const strongPassword = 'MySecurePass123!';
      const result = validatePassword(strongPassword);
      
      expect(result.valid).toBe(true);
      expect(result.errors.length).toBe(0);
      console.log('✅ Strong passwords are accepted');
    });

    it('should reject weak passwords', () => {
      const weakPassword = 'weak';
      const result = validatePassword(weakPassword);
      
      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      console.log('✅ Weak passwords are rejected');
    });

    it('should reject passwords without uppercase', () => {
      const password = 'mysecurepass123!';
      const result = validatePassword(password);
      
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.includes('كبير'))).toBe(true);
      console.log('✅ Passwords without uppercase are rejected');
    });

    it('should reject passwords without numbers', () => {
      const password = 'MySecurePass!';
      const result = validatePassword(password);
      
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.includes('رقم'))).toBe(true);
      console.log('✅ Passwords without numbers are rejected');
    });

    it('should reject passwords without special characters', () => {
      const password = 'MySecurePass123';
      const result = validatePassword(password);
      
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.includes('رمز'))).toBe(true);
      console.log('✅ Passwords without special characters are rejected');
    });
  });

  describe('Input Sanitization', () => {
    it('should remove HTML tags', () => {
      const input = 'Hello <script>alert("xss")</script> World';
      const sanitized = sanitizeInput(input);
      
      expect(sanitized).not.toContain('<');
      expect(sanitized).not.toContain('>');
      console.log('✅ HTML tags are removed');
    });

    it('should trim whitespace', () => {
      const input = '   Hello World   ';
      const sanitized = sanitizeInput(input);
      
      expect(sanitized).toBe('Hello World');
      console.log('✅ Whitespace is trimmed');
    });

    it('should limit input length', () => {
      const longInput = 'A'.repeat(2000);
      const sanitized = sanitizeInput(longInput);
      
      expect(sanitized.length).toBeLessThanOrEqual(1000);
      console.log('✅ Input length is limited');
    });

    it('should handle Arabic text', () => {
      const arabicText = 'السلام عليكم ورحمة الله';
      const sanitized = sanitizeInput(arabicText);
      
      expect(sanitized).toBe(arabicText);
      console.log('✅ Arabic text is preserved');
    });
  });

  describe('HTML Escaping', () => {
    it('should escape HTML special characters', () => {
      const html = '<script>alert("xss")</script>';
      const escaped = escapeHtml(html);
      
      expect(escaped).not.toContain('<');
      expect(escaped).not.toContain('>');
      expect(escaped).toContain('&lt;');
      expect(escaped).toContain('&gt;');
      console.log('✅ HTML special characters are escaped');
    });

    it('should escape quotes', () => {
      const html = 'He said "Hello" and \'Goodbye\'';
      const escaped = escapeHtml(html);
      
      expect(escaped).toContain('&quot;');
      expect(escaped).toContain('&#039;');
      console.log('✅ Quotes are escaped');
    });

    it('should escape ampersand', () => {
      const html = 'Tom & Jerry';
      const escaped = escapeHtml(html);
      
      expect(escaped).toContain('&amp;');
      console.log('✅ Ampersand is escaped');
    });
  });

  describe('Security Headers', () => {
    it('should return security headers', () => {
      const headers = getSecurityHeaders();
      
      expect(headers['X-Content-Type-Options']).toBe('nosniff');
      expect(headers['X-Frame-Options']).toBe('DENY');
      expect(headers['X-XSS-Protection']).toContain('1; mode=block');
      expect(headers['Strict-Transport-Security']).toBeDefined();
      expect(headers['Content-Security-Policy']).toBeDefined();
      console.log('✅ Security headers are properly configured');
    });

    it('should include HSTS header', () => {
      const headers = getSecurityHeaders();
      
      expect(headers['Strict-Transport-Security']).toContain('max-age=31536000');
      expect(headers['Strict-Transport-Security']).toContain('includeSubDomains');
      console.log('✅ HSTS header is configured');
    });

    it('should include CSP header', () => {
      const headers = getSecurityHeaders();
      
      expect(headers['Content-Security-Policy']).toBeDefined();
      expect(headers['Content-Security-Policy']).toContain('default-src');
      console.log('✅ CSP header is configured');
    });
  });
});
