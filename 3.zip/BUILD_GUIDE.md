# دليل البناء والنشر - الرايق أفاتار مصر

## المتطلبات

### للويب
- Node.js 18+
- pnpm

### لـ Android APK
- Java Development Kit (JDK) 11+
- Android SDK
- Android Studio (اختياري)
- Gradle

---

## خطوات البناء

### 1. البناء للويب

```bash
# تثبيت المتطلبات
pnpm install

# بناء التطبيق للإنتاج
pnpm build

# تشغيل التطبيق محلياً
pnpm start
```

### 2. البناء لـ Android

#### الخطوة 1: بناء الملفات الثابتة
```bash
pnpm build
```

#### الخطوة 2: نسخ الملفات إلى Capacitor
```bash
npx cap sync android
```

#### الخطوة 3: بناء APK

**للتطوير (Debug APK):**
```bash
cd android
./gradlew assembleDebug
```

**للإنتاج (Release APK):**
```bash
cd android
./gradlew assembleRelease
```

#### الخطوة 4: توقيع APK (للإنتاج فقط)

```bash
# إنشاء مفتاح توقيع
keytool -genkey -v -keystore my-release-key.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias my-key-alias

# توقيع APK
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
  -keystore my-release-key.keystore \
  app-release-unsigned.apk my-key-alias

# تحسين APK
zipalign -v 4 app-release-unsigned.apk app-release.apk
```

---

## مسارات الملفات المهمة

| الملف/المجلد | الوصف |
|-------------|--------|
| `dist/` | ملفات البناء للويب |
| `dist/public/` | الملفات الثابتة (HTML, CSS, JS) |
| `android/` | مشروع Android |
| `android/app/build/outputs/apk/` | ملفات APK المُنشأة |
| `capacitor.config.ts` | إعدادات Capacitor |

---

## متغيرات البيئة

تأكد من وجود المتغيرات التالية:

```bash
# قاعدة البيانات
DATABASE_URL=mysql://user:password@host:port/database

# المصادقة
JWT_SECRET=your-secret-key

# Manus OAuth
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://auth.manus.im

# Gemini API
GEMINI_API_KEY=your-gemini-api-key

# Manus APIs
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your-forge-key
VITE_FRONTEND_FORGE_API_KEY=your-frontend-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
```

---

## الاختبار

### اختبار الويب محلياً

```bash
# تشغيل خادم التطوير
pnpm dev

# تشغيل الاختبارات
pnpm test

# فحص TypeScript
pnpm check
```

### اختبار APK

```bash
# تثبيت APK على جهاز محاكاة أو هاتف
adb install android/app/build/outputs/apk/debug/app-debug.apk

# أو
adb install android/app/build/outputs/apk/release/app-release.apk
```

---

## النشر

### نشر الويب

التطبيق متاح على:
```
https://raiqavatar-hw3rhvzb.manus.space
```

### نشر Android

1. **متجر Google Play:**
   - إنشاء حساب Google Play Developer
   - تحضير APK موقع
   - تحميل APK والمعلومات
   - الانتظار للموافقة

2**توزيع مباشر:**
   - إرسال APK للمستخدمين مباشرة
   - أو استخدام خدمة توزيع مثل Firebase App Distribution

---

## استكشاف الأخطاء

### خطأ: "The web assets directory must contain an index.html"

**الحل:**
```bash
cp dist/public/index.html dist/index.html
npx cap sync android
```

### خطأ: "Gradle build failed"

**الحل:**
```bash
cd android
./gradlew clean
./gradlew assembleDebug
```

### خطأ: "Cannot find Android SDK"

**الحل:**
```bash
# تعيين متغير البيئة
export ANDROID_SDK_ROOT=/path/to/android/sdk
export ANDROID_HOME=/path/to/android/sdk
```

---

## الأداء والتحسينات

### تقليل حجم APK

1. استخدام ProGuard/R8 للتصغير
2. إزالة الملفات غير الضرورية
3. استخدام Dynamic Feature Modules

### تحسين الأداء

1. تفعيل Code Splitting
2. استخدام Lazy Loading
3. تحسين حجم Bundle

---

## الدعم والمساعدة

- **Capacitor Docs:** https://capacitorjs.com/docs
- **Android Docs:** https://developer.android.com/docs
- **Gradle Docs:** https://gradle.org/guides

---

## الإصدار

**الإصدار الحالي:** 1.0.0  
**آخر تحديث:** مارس 2026

---

## الترخيص

جميع الحقوق محفوظة © 2026 الرايق أفاتار مصر
