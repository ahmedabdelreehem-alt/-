# API Documentation - الرايق أفاتار مصر

## نظرة عامة
هذا التطبيق يستخدم **tRPC** للاتصال بين الواجهة الأمامية والخادم. جميع الاتصالات آمنة وتتطلب المصادقة.

---

## Base URL
```
https://raiqavatar-hw3rhvzb.manus.space/api/trpc
```

---

## المصادقة (Authentication)

### تسجيل الدخول
- يتم تسجيل الدخول عبر **Manus OAuth**
- يتم حفظ الجلسة في **JWT Cookie**
- كل طلب يتطلب الـ Cookie للمصادقة

### رفع الصلاحيات
```
GET /api/oauth/callback?code=...&state=...
```

---

## Endpoints - tRPC Procedures

### 1. نظام الدردشة (Chat System)

#### إنشاء محادثة جديدة
```typescript
POST /api/trpc/chat.createConversation
Body: {}
Response: { success: true, conversationId: number }
```

#### الحصول على المحادثات
```typescript
GET /api/trpc/chat.getConversations?input={"limit":50,"offset":0}
Response: Array<{
  id: number;
  userId: number;
  title: string;
  createdAt: Date;
  updatedAt: Date;
}>
```

#### إرسال رسالة
```typescript
POST /api/trpc/chat.sendMessage
Body: {
  conversationId: number;
  message: string;
}
Response: {
  success: true;
  response: string; // الرد من Gemini AI
}
```

#### الحصول على الرسائل
```typescript
GET /api/trpc/chat.getMessages?input={"conversationId":1,"limit":100}
Response: Array<{
  id: number;
  conversationId: number;
  userId: number;
  role: 'user' | 'assistant';
  content: string;
  createdAt: Date;
}>
```

---

### 2. نظام الأفاتار (Avatar System)

#### الحصول على إعدادات الأفاتار
```typescript
GET /api/trpc/avatar.getSettings
Response: {
  id: number;
  userId: number;
  voiceGender: 'male' | 'female';
  voicePitch: number;
  voiceRate: number;
  animationSpeed: number;
  backgroundColor: string;
  createdAt: Date;
}
```

#### تحديث إعدادات الأفاتار
```typescript
POST /api/trpc/avatar.updateSettings
Body: {
  voiceGender?: 'male' | 'female';
  voicePitch?: number;
  voiceRate?: number;
  animationSpeed?: number;
  backgroundColor?: string;
}
Response: { success: true }
```

---

### 3. نظام المستخدم (User System)

#### الحصول على بيانات المستخدم الحالي
```typescript
GET /api/trpc/auth.me
Response: {
  id: number;
  openId: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  createdAt: Date;
}
```

#### تسجيل الخروج
```typescript
POST /api/trpc/auth.logout
Response: { success: true }
```

---

### 4. نظام الإدارة (Admin System)

#### الحصول على قائمة المستخدمين (Admin فقط)
```typescript
GET /api/trpc/admin.getUsers?input={"limit":50,"offset":0}
Response: Array<{
  id: number;
  name: string;
  email: string;
  role: 'user' | 'admin';
  createdAt: Date;
  lastSignedIn: Date;
}>
```

#### تحديث صلاحية المستخدم (Admin فقط)
```typescript
POST /api/trpc/admin.updateUserRole
Body: {
  userId: number;
  role: 'user' | 'admin';
}
Response: { success: true }
```

#### الحصول على الإحصائيات (Admin فقط)
```typescript
GET /api/trpc/admin.getStats
Response: {
  totalUsers: number;
  totalConversations: number;
  totalMessages: number;
  activeUsers: number;
  averageMessagesPerUser: number;
}
```

---

### 5. نظام الذاكرة (Memory System)

#### حفظ ذاكرة
```typescript
POST /api/trpc/memory.store
Body: {
  content: string;
  type: 'short_term' | 'long_term';
}
Response: { success: true }
```

#### استرجاع الذاكرة
```typescript
GET /api/trpc/memory.retrieve?input={"type":"short_term","limit":10}
Response: Array<{
  id: number;
  content: string;
  type: 'short_term' | 'long_term';
  createdAt: Date;
}>
```

---

## أمثلة الاستخدام

### مثال 1: إرسال رسالة والحصول على رد

```typescript
import { trpc } from '@/lib/trpc';

// إنشاء محادثة
const { conversationId } = await trpc.chat.createConversation.mutate({});

// إرسال رسالة
const response = await trpc.chat.sendMessage.mutate({
  conversationId,
  message: 'السلام عليكم، كيف حالك؟'
});

console.log(response.response); // رد الأفاتار
```

### مثال 2: استخدام Speech-to-Text

```typescript
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';

const { startListening, transcript } = useSpeechRecognition({
  language: 'ar-SA',
  onResult: (text, isFinal) => {
    if (isFinal) {
      console.log('النص النهائي:', text);
    }
  }
});

// بدء الاستماع
startListening();
```

### مثال 3: استخدام Text-to-Speech

```typescript
import { useTextToSpeech } from '@/hooks/useTextToSpeech';

const { speak } = useTextToSpeech({
  language: 'ar-SA',
});

// تحويل النص إلى صوت
speak('السلام عليكم ورحمة الله وبركاته');
```

---

## معالجة الأخطاء

### رموز الأخطاء الشائعة

| الرمز | المعنى | الحل |
|------|--------|------|
| `UNAUTHORIZED` | لم يتم تسجيل الدخول | قم بتسجيل الدخول أولاً |
| `FORBIDDEN` | لا توجد صلاحيات كافية | تحقق من دورك (role) |
| `NOT_FOUND` | المورد غير موجود | تحقق من معرّف المورد |
| `INVALID_INPUT` | البيانات المدخلة غير صحيحة | تحقق من صيغة البيانات |
| `INTERNAL_SERVER_ERROR` | خطأ في الخادم | حاول مرة أخرى لاحقاً |

### مثال معالجة الخطأ

```typescript
try {
  const response = await trpc.chat.sendMessage.mutate({
    conversationId,
    message: 'مرحبا'
  });
} catch (error) {
  if (error.code === 'UNAUTHORIZED') {
    // إعادة توجيه إلى تسجيل الدخول
  } else if (error.code === 'INVALID_INPUT') {
    console.error('البيانات المدخلة غير صحيحة:', error.message);
  }
}
```

---

## الحدود والقيود

| الحد | القيمة |
|-----|--------|
| حد أقصى لطول الرسالة | 5000 حرف |
| حد أقصى للرسائل في المحادثة | 10000 رسالة |
| حد أقصى لعدد المحادثات | غير محدود |
| حد أقصى للطلبات في الدقيقة | 60 طلب |
| مدة انتهاء الجلسة | 30 يوم |

---

## الأمان

### معايير الأمان المطبقة

1. **تشفير البيانات** - جميع البيانات الحساسة مشفرة
2. **JWT Authentication** - المصادقة عبر JWT
3. **CORS Protection** - حماية من طلبات CORS غير المصرح بها
4. **Rate Limiting** - تحديد عدد الطلبات
5. **Input Validation** - التحقق من صحة المدخلات
6. **SQL Injection Prevention** - حماية من هجمات SQL
7. **XSS Protection** - حماية من هجمات XSS

---

## الإصدار

**الإصدار الحالي:** 1.0.0  
**آخر تحديث:** مارس 2026

---

## الدعم

للمساعدة والدعم، يرجى التواصل عبر:
- البريد الإلكتروني: support@raiqavatar.com
- الموقع: https://raiqavatar-hw3rhvzb.manus.space

---

## الترخيص

جميع الحقوق محفوظة © 2026 الرايق أفاتار مصر
