import { useEffect, useRef, useState, useCallback } from 'react';

interface UseTextToSpeechProps {
  language?: string;
  rate?: number;
  pitch?: number;
  volume?: number;
  voiceIndex?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: string) => void;
}

export const useTextToSpeech = ({
  language = 'ar-SA',
  rate = 1,
  pitch = 1,
  volume = 1,
  voiceIndex = 0,
  onStart,
  onEnd,
  onError,
}: UseTextToSpeechProps) => {
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const [isSupported, setIsSupported] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    // Check browser support
    const synth = window.speechSynthesis;
    
    if (!synth) {
      setIsSupported(false);
      console.warn('Text-to-Speech API not supported in this browser');
      return;
    }

    setIsSupported(true);
    synthRef.current = synth;

    // Get available voices
    const updateVoices = () => {
      const availableVoices = synth.getVoices();
      setVoices(availableVoices);
    };

    updateVoices();
    synth.onvoiceschanged = updateVoices;

    return () => {
      if (synth) {
        synth.cancel();
      }
    };
  }, []);

  const speak = useCallback(
    (text: string) => {
      if (!synthRef.current || !isSupported) {
        console.warn('Text-to-Speech not supported');
        return;
      }

      // Cancel any ongoing speech
      synthRef.current.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = language;
      utterance.rate = rate;
      utterance.pitch = pitch;
      utterance.volume = volume;

      // Set voice if available
      if (voices.length > 0) {
        const selectedVoice = voices.find((v) => v.lang.startsWith(language.split('-')[0])) || voices[voiceIndex];
        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }
      }

      utterance.onstart = () => {
        setIsSpeaking(true);
        onStart?.();
      };

      utterance.onend = () => {
        setIsSpeaking(false);
        onEnd?.();
      };

      utterance.onerror = (event) => {
        const errorMessage = `Text-to-Speech error: ${event.error}`;
        console.error(errorMessage);
        onError?.(event.error);
        setIsSpeaking(false);
      };

      synthRef.current.speak(utterance);
    },
    [language, rate, pitch, volume, voiceIndex, voices, isSupported, onStart, onEnd, onError]
  );

  const stop = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  }, []);

  const pause = useCallback(() => {
    if (synthRef.current && synthRef.current.paused === false) {
      synthRef.current.pause();
    }
  }, []);

  const resume = useCallback(() => {
    if (synthRef.current && synthRef.current.paused === true) {
      synthRef.current.resume();
    }
  }, []);

  return {
    speak,
    stop,
    pause,
    resume,
    isSpeaking,
    isSupported,
    voices,
  };
};
